import "dotenv/config";
import express, { Request, Response, NextFunction } from "express";
import axios from "axios";
import { z } from "zod";

const envSchema = z.object({
  WHATSAPP_TOKEN: z.string().min(1),
  PHONE_NUMBER_ID: z.string().min(1),
  PORT: z.string().optional().default("3000"),
});

const envResult = envSchema.safeParse(process.env);

if (!envResult.success) {
  console.error(envResult.error.format());
  process.exit(1);
}

const { WHATSAPP_TOKEN, PHONE_NUMBER_ID, PORT } = envResult.data;

const app = express();
app.use(express.json());

const WHATSAPP_API_URL = `https://graph.facebook.com/v21.0/${PHONE_NUMBER_ID}/messages`;

const sendWhatsAppSchema = z.object({
  to: z.string().min(8).max(15).regex(/^\d+$/),
  message: z.string().min(1).max(1000),
  imageUrl: z.string().url().optional(),
});

type SendWhatsAppBody = z.infer<typeof sendWhatsAppSchema>;

app.post("/send-whatsapp", async (req: Request, res: Response) => {
  try {
    const parseResult = sendWhatsAppSchema.safeParse(req.body);

    if (!parseResult.success) {
      return res.status(400).json({
        success: false,
        error: "Datos inválidos",
        details: parseResult.error.format(),
      });
    }

    const { to, message, imageUrl } = parseResult.data as SendWhatsAppBody;

    let data: any;

    if (imageUrl) {
      data = {
        messaging_product: "whatsapp",
        to,
        type: "image",
        image: { link: imageUrl, caption: message },
      };
    } else {
      data = {
        messaging_product: "whatsapp",
        to,
        type: "text",
        text: { body: message },
      };
    }

    const response = await axios.post(WHATSAPP_API_URL, data, {
      headers: {
        Authorization: `Bearer ${WHATSAPP_TOKEN}`,
        "Content-Type": "application/json",
      },
    });

    return res.status(200).json({ success: true, whatsappResponse: response.data });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: "Error enviando mensaje",
      details: error.response?.data || error.message,
    });
  }
});

app.get("/", (_req: Request, res: Response) => {
  res.send("Servidor WhatsApp API con TypeScript funcionando");
});

app.listen(Number(PORT), () => {
  console.log(`Servidor en http://localhost:${PORT}`);
});
