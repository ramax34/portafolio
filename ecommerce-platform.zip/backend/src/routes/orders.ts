
import { Router, Request, Response } from "express";
import { z } from "zod";
import { products } from "../data/products";

const router = Router();

const orderSchema = z.object({
  items: z.array(
    z.object({
      productId: z.string(),
      quantity: z.number().min(1)
    })
  ),
  customer: z.object({
    name: z.string().min(1),
    email: z.string().email()
  })
});

router.post("/", (req: Request, res: Response) => {
  const parsed = orderSchema.safeParse(req.body);

  if (!parsed.success) {
    return res.status(400).json({
      success: false,
      error: "Datos de pedido inválidos",
      details: parsed.error.format(),
    });
  }

  const { items, customer } = parsed.data;

  const detailedItems = items.map(item => {
    const product = products.find(p => p.id === item.productId);
    if (!product) {
      throw new Error(`Producto no encontrado: ${item.productId}`);
    }
    return {
      productId: item.productId,
      name: product.name,
      price: product.price,
      quantity: item.quantity,
      subtotal: product.price * item.quantity,
    };
  });

  const total = detailedItems.reduce((acc, item) => acc + item.subtotal, 0);

  const orderId = "ORD-" + Math.random().toString(36).substring(2, 10).toUpperCase();

  // Aquí podrías integrar una pasarela de pagos real (Stripe/PayPal)
  // Por ahora simulamos que el pago fue exitoso.
  const order = {
    id: orderId,
    customer,
    items: detailedItems,
    total,
    status: "paid",
    createdAt: new Date().toISOString(),
  };

  return res.status(201).json({
    success: true,
    order,
    message: "Pedido creado y pago simulado con éxito ✅",
  });
});

export default router;
