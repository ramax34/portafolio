
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Camiseta React",
    description: "Camiseta cómoda con diseño de React para desarrolladores.",
    price: 25,
    image: "https://via.placeholder.com/300x200?text=Camiseta+React",
    category: "Ropa"
  },
  {
    id: "2",
    name: "Taza JavaScript",
    description: "Taza para café con logo de JavaScript.",
    price: 15,
    image: "https://via.placeholder.com/300x200?text=Taza+JavaScript",
    category: "Accesorios"
  },
  {
    id: "3",
    name: "Sticker Pack Dev",
    description: "Pack de stickers para tu laptop con temática de programación.",
    price: 8,
    image: "https://via.placeholder.com/300x200?text=Stickers+Dev",
    category: "Accesorios"
  }
];
