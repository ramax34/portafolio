
# 🛒 E-commerce Platform (Demo)

Plataforma simple de comercio electrónico con:

- Backend en Node.js + TypeScript + Express
- Frontend en React + Vite + TypeScript
- Catálogo de productos
- Carrito de compras en el frontend
- Checkout con creación de pedido y pago simulado

## Cómo usar

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

El backend se levantará en `http://localhost:4000`.

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

El frontend se levantará en `http://localhost:5173`.

Asegúrate de que el backend esté corriendo antes de usar la tienda.
