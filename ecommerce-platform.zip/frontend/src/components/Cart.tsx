
import React from "react";
import { useCart } from "../context/CartContext";

export const Cart: React.FC = () => {
  const { items, removeFromCart, total } = useCart();

  if (items.length === 0) {
    return <p style={{ marginTop: "2rem" }}>Tu carrito está vacío.</p>;
  }

  return (
    <div style={{ marginTop: "2rem" }}>
      <h2>🧺 Carrito</h2>
      <ul>
        {items.map(item => (
          <li key={item.product.id} style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.5rem" }}>
            <span>
              {item.product.name} x {item.quantity}
            </span>
            <span>
              ${(item.product.price * item.quantity).toFixed(2)}{" "}
              <button onClick={() => removeFromCart(item.product.id)} style={{ marginLeft: "0.5rem" }}>
                Quitar
              </button>
            </span>
          </li>
        ))}
      </ul>
      <p><strong>Total: ${total.toFixed(2)}</strong></p>
    </div>
  );
};
