
import React, { useState } from "react";
import { useCart } from "../context/CartContext";
import { api } from "../services/api";

export const Checkout: React.FC = () => {
  const { items, total, clearCart } = useCart();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      setMessage("No tienes productos en el carrito.");
      return;
    }
    setLoading(true);
    setMessage(null);
    try {
      const body = {
        items: items.map(i => ({
          productId: i.product.id,
          quantity: i.quantity,
        })),
        customer: { name, email },
      };
      const res = await api.post("/orders", body);
      setMessage("Pedido realizado con éxito. ID: " + res.order.id);
      clearCart();
      setName("");
      setEmail("");
    } catch (err) {
      console.error(err);
      setMessage("Error al procesar el pedido.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ marginTop: "2rem" }}>
      <h2>💳 Checkout</h2>
      <p>Total a pagar: <strong>${total.toFixed(2)}</strong></p>
      <form onSubmit={handleSubmit} style={{ display: "grid", gap: "0.5rem", maxWidth: "320px" }}>
        <input
          type="text"
          placeholder="Nombre"
          value={name}
          onChange={e => setName(e.target.value)}
          required
        />
        <input
          type="email"
          placeholder="Correo electrónico"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? "Procesando..." : "Finalizar compra"}
        </button>
      </form>
      {message && <p style={{ marginTop: "0.5rem" }}>{message}</p>}
    </div>
  );
};
