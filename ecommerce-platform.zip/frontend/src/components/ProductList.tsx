
import React, { useEffect, useState } from "react";
import { useCart, Product } from "../context/CartContext";
import { api } from "../services/api";

export const ProductList: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { addToCart } = useCart();

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const res = await api.get<Product[]>("/products");
        setProducts(res);
      } catch (err) {
        console.error(err);
        setError("Error cargando productos");
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  if (loading) return <p>Cargando productos...</p>;
  if (error) return <p style={{ color: "red" }}>{error}</p>;

  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "1rem", marginTop: "1.5rem" }}>
      {products.map(product => (
        <div key={product.id} style={{ border: "1px solid #ddd", borderRadius: "8px", padding: "1rem" }}>
          <img src={product.image} alt={product.name} style={{ width: "100%", borderRadius: "4px" }} />
          <h3>{product.name}</h3>
          <p style={{ fontSize: "0.9rem" }}>{product.description}</p>
          <p><strong>${product.price.toFixed(2)}</strong></p>
          <button onClick={() => addToCart(product)}>Añadir al carrito</button>
        </div>
      ))}
    </div>
  );
};
