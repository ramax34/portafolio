
import React from "react";
import { CartProvider } from "./context/CartContext";
import { ProductList } from "./components/ProductList";
import { Cart } from "./components/Cart";
import { Checkout } from "./components/Checkout";

const App: React.FC = () => {
  return (
    <CartProvider>
      <div style={{ maxWidth: "960px", margin: "0 auto", padding: "1rem" }}>
        <h1 style={{ textAlign: "center" }}>🛒 E-commerce Platform</h1>
        <p style={{ textAlign: "center" }}>
          Ejemplo simple de tienda con carrito y checkout simulado.
        </p>
        <ProductList />
        <Cart />
        <Checkout />
      </div>
    </CartProvider>
  );
};

export default App;
