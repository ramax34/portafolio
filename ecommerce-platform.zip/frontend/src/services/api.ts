
const BASE_URL = "http://localhost:4000/api";

async function request(path: string, options?: RequestInit) {
  const res = await fetch(BASE_URL + path, {
    headers: {
      "Content-Type": "application/json",
    },
    ...options,
  });

  if (!res.ok) {
    const errorBody = await res.text();
    throw new Error(errorBody || "Error en la petición");
  }

  return res.json();
}

export const api = {
  get: <T>(path: string): Promise<T> => request(path),
  post: <T>(path: string, body: unknown): Promise<T> =>
    request(path, {
      method: "POST",
      body: JSON.stringify(body),
    }),
};
