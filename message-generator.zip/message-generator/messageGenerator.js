const subjects=["Today","This week","Tomorrow","Right now","This month"];
const actions=["you will discover","you will overcome","you will achieve","you will receive","you will create"];
const endings=["a great opportunity.","something that changes your life.","a new friendship.","the confidence you need.","an unexpected success."];
const getRandomItem=a=>a[Math.floor(Math.random()*a.length)];
const generateMessage=()=>`${getRandomItem(subjects)}, ${getRandomItem(actions)} ${getRandomItem(endings)}`;
console.log("========== Random Message Generator ==========");
console.log(generateMessage());
console.log("==============================================");