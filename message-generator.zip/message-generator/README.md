# Random Message Generator

Run:
```bash
npm start
```
or
```bash
node messageGenerator.js
```
