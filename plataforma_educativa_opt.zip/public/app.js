
const API_BASE = "";
let currentUser = null;
let enrollmentsCache = [];
let studentsCache = [];

// ---------- helpers ----------
function formToJSON(form) {
  const data = new FormData(form);
  return Object.fromEntries(data.entries());
}

function authHeaders() {
  if (!currentUser) return {};
  return { "x-role": currentUser.role };
}

function getCurrentStudentId() {
  if (!currentUser || currentUser.role !== "alumno") return null;
  const student = studentsCache.find((s) => s.email === currentUser.email);
  return student ? student.id : null;
}

function getEnrollmentForStudentAndCourse(studentId, courseId) {
  return enrollmentsCache.find(
    (e) => e.studentId === studentId && e.courseId === Number(courseId)
  );
}

// ---------- login ----------
const loginScreen = document.getElementById("login-screen");
const appRoot = document.getElementById("app-root");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.style.display = "none";
  const payload = formToJSON(loginForm);
  try {
    const res = await fetch(API_BASE + "/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      loginError.style.display = "block";
      return;
    }
    const data = await res.json();
    currentUser = data.user;
    localStorage.setItem("lmsUser", JSON.stringify(currentUser));
    enterApp();
  } catch {
    loginError.style.display = "block";
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  localStorage.removeItem("lmsUser");
  currentUser = null;
  location.reload();
});

function enterApp() {
  loginScreen.style.display = "none";
  appRoot.style.display = "block";
  document.getElementById("user-name").textContent = currentUser.name;
  document.getElementById("user-role").textContent = currentUser.role;
  adjustUIForRole();
  initApp();
}

const stored = localStorage.getItem("lmsUser");
if (stored) {
  currentUser = JSON.parse(stored);
  enterApp();
}

function adjustUIForRole() {
  if (!currentUser) return;
  const role = currentUser.role;

  const formCourse = document.getElementById("form-course");
  const formStudent = document.getElementById("form-student");
  const formEnrollment = document.getElementById("form-enrollment");
  const formLesson = document.getElementById("form-lesson");
  const formCertificate = document.getElementById("form-certificate");

  if (role === "alumno") {
    if (formCourse) formCourse.style.display = "none";
    if (formStudent) formStudent.style.display = "none";
    if (formEnrollment) formEnrollment.style.display = "none";
    if (formLesson) formLesson.style.display = "none";
    if (formCertificate) formCertificate.style.display = "none";
  } else if (role === "profesor") {
    if (formStudent) formStudent.style.display = "none";
  }
}

// ---------- tabs ----------
const tabs = document.querySelectorAll(".tab");
const views = {
  dashboard: document.getElementById("view-dashboard"),
  cursos: document.getElementById("view-cursos"),
  alumnos: document.getElementById("view-alumnos"),
  inscripciones: document.getElementById("view-inscripciones"),
  certificados: document.getElementById("view-certificados"),
};

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const view = tab.dataset.view;
    tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    Object.keys(views).forEach((key) => {
      views[key].style.display = key === view ? "block" : "none";
    });
  });
});

// ---------- dashboard ----------
let chartEnrollments = null;
let chartProgress = null;

async function loadOverview() {
  const res = await fetch(API_BASE + "/api/stats/overview");
  const data = await res.json();
  document.getElementById("kpi-total-courses").textContent = data.totalCourses;
  document.getElementById("kpi-total-students").textContent = data.totalStudents;
  document.getElementById("kpi-total-enrollments").textContent = data.totalEnrollments;
  document.getElementById("kpi-total-certificates").textContent = data.totalCertificates;
}

async function loadEnrollmentsChart() {
  const res = await fetch(API_BASE + "/api/stats/enrollments-by-course");
  const data = await res.json();
  const ctx = document.getElementById("chart-enrollments").getContext("2d");

  if (chartEnrollments) chartEnrollments.destroy();

  chartEnrollments = new Chart(ctx, {
    type: "bar",
    data: {
      labels: data.map((d) => d.title),
      datasets: [
        {
          label: "Inscripciones",
          data: data.map((d) => d.enrollments),
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false }, ticks: { color: "#9ca3af" } },
        y: { grid: { color: "rgba(55,65,81,0.6)" }, ticks: { color: "#9ca3af" } },
      },
      plugins: { legend: { labels: { color: "#e5e7eb" } } },
    },
  });
}

async function loadProgressChart() {
  const res = await fetch(API_BASE + "/api/stats/course-progress");
  const data = await res.json();
  const ctx = document.getElementById("chart-progress").getContext("2d");

  if (chartProgress) chartProgress.destroy();

  chartProgress = new Chart(ctx, {
    type: "line",
    data: {
      labels: data.map((d) => d.title),
      datasets: [
        {
          label: "Progreso promedio (%)",
          data: data.map((d) => d.avgCompletion),
          tension: 0.35,
          borderWidth: 2,
          pointRadius: 3,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false }, ticks: { color: "#9ca3af" } },
        y: {
          grid: { color: "rgba(55,65,81,0.6)" },
          ticks: { color: "#9ca3af" },
          suggestedMin: 0,
          suggestedMax: 100,
        },
      },
      plugins: { legend: { labels: { color: "#e5e7eb" } } },
    },
  });
}

// ---------- cursos ----------
async function loadCourses() {
  const res = await fetch(API_BASE + "/api/courses");
  const courses = await res.json();

  const list = document.getElementById("courses-list");
  list.innerHTML = "";

  courses.forEach((c) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${c.title}</div>
          <div class="list-item-meta">${c.category || "Sin categoría"}</div>
        </div>
        <span class="badge badge-level-${c.level}">${c.level}</span>
      </div>
      <div class="list-item-meta">Lecciones totales: ${c.totalLessons}</div>
    `;
    list.appendChild(item);
  });

  const enrollmentCourseSelect = document.getElementById("enrollment-course-select");
  const lessonsCourseSelect = document.getElementById("lessons-course-select");
  const lessonCourseSelect = document.getElementById("lesson-course-select");

  enrollmentCourseSelect.innerHTML = "";
  lessonsCourseSelect.innerHTML = "";
  lessonCourseSelect.innerHTML = "";

  courses.forEach((c) => {
    const opt1 = document.createElement("option");
    opt1.value = c.id;
    opt1.textContent = c.title;
    enrollmentCourseSelect.appendChild(opt1);

    const opt2 = document.createElement("option");
    opt2.value = c.id;
    opt2.textContent = c.title;
    lessonsCourseSelect.appendChild(opt2);

    const opt3 = document.createElement("option");
    opt3.value = c.id;
    opt3.textContent = c.title;
    lessonCourseSelect.appendChild(opt3);
  });
}

function setupCourseForm() {
  const form = document.getElementById("form-course");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/courses", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar curso (¿tienes permisos?)");
      return;
    }
    form.reset();
    await Promise.all([loadCourses(), loadOverview(), loadEnrollmentsChart(), loadProgressChart()]);
  });
}

// ---------- lecciones ----------
async function loadLessons(courseId) {
  const res = await fetch(API_BASE + `/api/courses/${courseId}/lessons`);
  const lessons = await res.json();
  const container = document.getElementById("lessons-list");
  container.innerHTML = "";

  lessons.forEach((l) => {
    const item = document.createElement("div");
    item.className = "list-item";
    let extra = "";
    if (l.type === "video" && l.url) {
      extra = `<div class="list-item-meta">Video: <a href="${l.url}" target="_blank">Ver video</a></div>`;
    } else if (l.type === "pdf" && l.url) {
      extra = `<div class="list-item-meta">PDF: <a href="${l.url}" target="_blank">Abrir PDF</a></div>`;
    } else if (l.type === "quiz" && l.quiz) {
      const optionsHtml = l.quiz.options
        .map(
          (opt, idx) =>
            `<button class="btn-ghost btn-xs quiz-option"
                data-lesson-id="${l.id}"
                data-course-id="${courseId}"
                data-correct="${idx === l.quiz.correctIndex}">
              ${opt}
            </button>`
        )
        .join(" ");
      extra = `
        <div class="list-item-meta">${l.quiz.question}</div>
        <div style="margin-top:4px; display:flex; flex-wrap:wrap; gap:4px;">${optionsHtml}</div>
      `;
    }

    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${l.order || ""} ${l.title}</div>
          <div class="list-item-meta">Tipo: ${l.type}</div>
        </div>
      </div>
      ${extra}
    `;
    container.appendChild(item);
  });

  container.querySelectorAll(".quiz-option").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const isCorrect = btn.dataset.correct === "true";
      const lessonId = Number(btn.dataset.lessonId);
      const courseIdNum = Number(btn.dataset.courseId);

      alert(isCorrect ? "✔ Respuesta correcta" : "✖ Respuesta incorrecta");

      if (!currentUser || currentUser.role !== "alumno") return;

      const studentId = getCurrentStudentId();
      if (!studentId) {
        alert("Tu usuario no está vinculado a un alumno demo.");
        return;
      }

      const enrollment = getEnrollmentForStudentAndCourse(studentId, courseIdNum);
      if (!enrollment) {
        alert("No tienes inscripción en este curso.");
        return;
      }

      await fetch(API_BASE + `/api/enrollments/${enrollment.id}/quiz-result`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ lessonId, correct: isCorrect }),
      });

      await Promise.all([loadEnrollments(), loadOverview(), loadProgressChart()]);
      const select = document.getElementById("progress-enrollment-select");
      if (select && select.value) {
        loadProgressDetail(select.value);
      }
    });
  });
}

function setupLessonsUI() {
  const btnLoadLessons = document.getElementById("btn-load-lessons");
  const lessonsCourseSelect = document.getElementById("lessons-course-select");
  if (btnLoadLessons && lessonsCourseSelect) {
    btnLoadLessons.addEventListener("click", () => {
      const id = lessonsCourseSelect.value;
      if (id) loadLessons(id);
    });
  }

  const lessonTypeSelect = document.getElementById("lesson-type");
  const quizExtra = document.getElementById("quiz-extra-fields");
  if (lessonTypeSelect) {
    lessonTypeSelect.addEventListener("change", () => {
      quizExtra.style.display = lessonTypeSelect.value === "quiz" ? "block" : "none";
    });
  }

  const formLesson = document.getElementById("form-lesson");
  if (formLesson) {
    formLesson.addEventListener("submit", async (e) => {
      e.preventDefault();
      const payload = formToJSON(formLesson);
      const courseId = payload.courseId;
      const type = payload.type;
      const body = {
        title: payload.title,
        type,
        url: payload.url,
        order: payload.order,
      };
      if (type === "quiz") {
        body.quiz = {
          question: payload.quizQuestion,
          options: (payload.quizOptions || "").split(",").map((s) => s.trim()).filter(Boolean),
          correctIndex: Number(payload.quizCorrectIndex) || 0,
        };
      }
      const res = await fetch(API_BASE + `/api/courses/${courseId}/lessons`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        alert("Error al guardar lección (¿tienes permisos?)");
        return;
      }
      formLesson.reset();
      await loadLessons(courseId);
    });
  }
}

// ---------- alumnos ----------
async function loadStudents() {
  const res = await fetch(API_BASE + "/api/students");
  const students = await res.json();
  studentsCache = students;

  const list = document.getElementById("students-list");
  list.innerHTML = "";

  students.forEach((s) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${s.name}</div>
          <div class="list-item-meta">${s.email}</div>
        </div>
      </div>
    `;
    list.appendChild(item);
  });

  const enrollmentStudentSelect = document.getElementById("enrollment-student-select");
  enrollmentStudentSelect.innerHTML = "";
  students.forEach((s) => {
    const opt = document.createElement("option");
    opt.value = s.id;
    opt.textContent = s.name;
    enrollmentStudentSelect.appendChild(opt);
  });
}

function setupStudentForm() {
  const form = document.getElementById("form-student");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/students", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar alumno (solo admin)");
      return;
    }
    form.reset();
    await Promise.all([loadStudents(), loadOverview()]);
  });
}

// ---------- inscripciones ----------
async function loadEnrollments() {
  const res = await fetch(API_BASE + "/api/enrollments");
  const enrollments = await res.json();
  enrollmentsCache = enrollments;

  const tbody = document.getElementById("enrollments-table-body");
  tbody.innerHTML = "";

  enrollments.forEach((e) => {
    const total = e.totalLessons || 0;
    const completed = e.completedLessons || 0;
    const pct = total ? Math.round((completed / total) * 100) : 0;

    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${e.studentName}</td>
      <td>${e.courseTitle}</td>
      <td>
        <div class="progress-track">
          <div class="progress-bar" style="width:${pct}%;"></div>
        </div>
        <div class="list-item-meta">${pct}% completado</div>
      </td>
      <td>${completed}/${total}</td>
    `;
    tbody.appendChild(tr);
  });

  const certificateEnrollmentSelect = document.getElementById("certificate-enrollment-select");
  const progressSelect = document.getElementById("progress-enrollment-select");
  certificateEnrollmentSelect.innerHTML = "";
  progressSelect.innerHTML = "";

  enrollments.forEach((e) => {
    const total = e.totalLessons || 0;
    const completed = e.completedLessons || 0;
    const pct = total ? Math.round((completed / total) * 100) : 0;

    const opt1 = document.createElement("option");
    opt1.value = e.id;
    opt1.textContent = `${e.studentName} - ${e.courseTitle} (${pct}% completado)`;
    certificateEnrollmentSelect.appendChild(opt1);

    const opt2 = document.createElement("option");
    opt2.value = e.id;
    opt2.textContent = `${e.studentName} - ${e.courseTitle}`;
    progressSelect.appendChild(opt2);
  });
}

function setupEnrollmentForm() {
  const form = document.getElementById("form-enrollment");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/enrollments", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al crear inscripción (¿tienes permisos?)");
      return;
    }
    form.reset();
    await Promise.all([loadEnrollments(), loadOverview(), loadEnrollmentsChart(), loadProgressChart()]);
  });
}

// ---------- progreso detallado ----------
async function loadProgressDetail(enrollmentId) {
  if (!enrollmentId) return;
  const res = await fetch(API_BASE + `/api/enrollments/${enrollmentId}/detail`);
  if (!res.ok) return;

  const data = await res.json();
  const container = document.getElementById("progress-enrollment-detail");
  container.innerHTML = "";

  const header = document.createElement("div");
  header.className = "list-item";
  header.innerHTML = `
    <div class="list-item-title">${data.courseTitle}</div>
    <div class="list-item-meta">
      Progreso: ${data.percentComplete}% ·
      Score quizzes: ${data.finalQuizScore != null ? data.finalQuizScore + "%" : "N/A"}
    </div>
  `;
  container.appendChild(header);

  data.lessons.forEach((l) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${l.order || ""} ${l.title}</div>
          <div class="list-item-meta">Tipo: ${l.type}</div>
        </div>
        <span class="badge">${l.completed ? "Completada" : "Pendiente"}</span>
      </div>
      <div class="list-item-meta">
        Score quiz: ${
          l.type === "quiz" && typeof l.score === "number" ? l.score + "%" : "-"
        }
      </div>
    `;
    container.appendChild(item);
  });
}

function setupProgressDetail() {
  const select = document.getElementById("progress-enrollment-select");
  if (!select) return;
  select.addEventListener("change", () => {
    if (select.value) loadProgressDetail(select.value);
  });
}

// ---------- certificados ----------
async function loadCertificates() {
  const res = await fetch(API_BASE + "/api/certificates");
  const certs = await res.json();
  const list = document.getElementById("certificates-list");
  list.innerHTML = "";

  certs.forEach((c) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${c.studentName}</div>
          <div class="list-item-meta">Curso: ${c.courseTitle}</div>
        </div>
        <span class="badge">${c.code}</span>
      </div>
      <div class="list-item-meta">Emitido: ${c.issuedAt}</div>
      <div style="margin-top:6px; display:flex; gap:6px; flex-wrap:wrap;">
        <a class="btn-ghost btn-xs" href="/api/certificates/${c.id}/pdf" target="_blank">Descargar PDF</a>
        <button class="btn-ghost btn-xs send-email-btn" data-id="${c.id}">Enviar por email</button>
      </div>
    `;
    list.appendChild(item);
  });

  list.querySelectorAll(".send-email-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.id;
      const email = prompt("Correo del destinatario:");
      if (!email) return;
      const res = await fetch(API_BASE + `/api/certificates/${id}/email`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders() },
        body: JSON.stringify({ to: email }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        alert(data.error || "No se pudo enviar el email");
        return;
      }
      alert(data.message || "Solicitud de envío realizada");
    });
  });
}

function setupCertificateForm() {
  const form = document.getElementById("form-certificate");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/certificates/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      alert(data.error || "No se pudo emitir el certificado");
      return;
    }
    alert("Certificado emitido: " + data.code);
    await Promise.all([loadCertificates(), loadOverview()]);
  });
}

// ---------- init ----------
async function initApp() {
  await Promise.all([
    loadOverview(),
    loadEnrollmentsChart(),
    loadProgressChart(),
    loadCourses(),
    loadStudents(),
    loadEnrollments(),
    loadCertificates(),
  ]);

  setupCourseForm();
  setupLessonsUI();
  setupStudentForm();
  setupEnrollmentForm();
  setupCertificateForm();
  setupProgressDetail();
}
