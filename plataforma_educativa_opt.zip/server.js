
const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');
const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data.json');

// --------------------- DATA ---------------------
function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    const seed = {
      users: [
        { id: 1, name: "Admin", email: "admin@example.com", password: "admin123", role: "admin" },
        { id: 2, name: "Profe", email: "profe@example.com", password: "profe123", role: "profesor" },
        { id: 3, name: "Alumno", email: "alumno@example.com", password: "alumno123", role: "alumno" }
      ],
      courses: [
        { id: 1, title: "Introducción a Programación", category: "Tecnología", level: "Básico", totalLessons: 3 },
        { id: 2, title: "Marketing Digital 101", category: "Marketing", level: "Intermedio", totalLessons: 2 }
      ],
      lessons: [
        { id: 1, courseId: 1, title: "Bienvenida al curso", type: "video", url: "https://www.youtube.com/", order: 1 },
        { id: 2, courseId: 1, title: "PDF de apoyo", type: "pdf", url: "https://example.com/guia-programacion.pdf", order: 2 },
        { id: 3, courseId: 1, title: "Quiz de variables", type: "quiz", order: 3,
          quiz: {
            question: "¿Cuál es un tipo de dato primitivo?",
            options: ["Clase", "Entero (int)", "Módulo", "Paquete"],
            correctIndex: 1
          }
        },
        { id: 4, courseId: 2, title: "Fundamentos de marketing", type: "video", url: "https://www.youtube.com/", order: 1 },
        { id: 5, courseId: 2, title: "Quiz de conceptos básicos", type: "quiz", order: 2,
          quiz: {
            question: "El embudo de ventas sirve para...",
            options: ["Diseñar logos", "Entender el recorrido del cliente", "Calcular impuestos", "Configurar servidores"],
            correctIndex: 1
          }
        }
      ],
      students: [
        { id: 1, name: "Ana López", email: "ana@example.com" },
        { id: 2, name: "Carlos Pérez", email: "carlos@example.com" }
      ],
      enrollments: [
        { id: 1, studentId: 1, courseId: 1, completedLessons: 2, enrolledAt: "2025-02-01", lessonProgress: [
          { lessonId: 1, completed: true, score: null },
          { lessonId: 2, completed: true, score: null }
        ]},
        { id: 2, studentId: 1, courseId: 2, completedLessons: 2, enrolledAt: "2025-03-10", lessonProgress: [
          { lessonId: 4, completed: true, score: null },
          { lessonId: 5, completed: true, score: 100 }
        ]},
        { id: 3, studentId: 2, courseId: 1, completedLessons: 3, enrolledAt: "2025-03-15", lessonProgress: [
          { lessonId: 1, completed: true, score: null },
          { lessonId: 2, completed: true, score: null },
          { lessonId: 3, completed: true, score: 100 }
        ]}
      ],
      certificates: [
        { id: 1, enrollmentId: 2, issuedAt: "2025-04-01", code: "CERT-0001" },
        { id: 2, enrollmentId: 3, issuedAt: "2025-04-05", code: "CERT-0002" }
      ]
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(seed, null, 2), 'utf8');
    return seed;
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(raw);
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

let db = loadData();

function getNextId(list) {
  if (!list.length) return 1;
  return Math.max(...list.map(i => i.id)) + 1;
}

function ensureLessonProgressArray(enrollment) {
  if (!enrollment.lessonProgress) {
    enrollment.lessonProgress = [];
  }
}

// --------------------- AUTH ---------------------
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email && u.password === password);
  if (!user) {
    return res.status(401).json({ error: "Credenciales inválidas" });
  }
  const token = "demo-" + user.id + "-" + Date.now();
  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    }
  });
});

function requireRole(roles) {
  return (req, res, next) => {
    const role = req.headers['x-role'];
    if (!role || !roles.includes(role)) {
      return res.status(403).json({ error: "No autorizado" });
    }
    next();
  };
}

// --------------------- COURSES ---------------------
app.get('/api/courses', (req, res) => {
  res.json(db.courses);
});

app.post('/api/courses', requireRole(['admin', 'profesor']), (req, res) => {
  const { title, category, level, totalLessons } = req.body;
  if (!title) return res.status(400).json({ error: "title es obligatorio" });
  const course = {
    id: getNextId(db.courses),
    title,
    category: category || "",
    level: level || "Básico",
    totalLessons: Number(totalLessons) || 0
  };
  db.courses.push(course);
  saveData(db);
  res.status(201).json(course);
});

// --------------------- LESSONS ---------------------
app.get('/api/courses/:id/lessons', (req, res) => {
  const courseId = Number(req.params.id);
  const lessons = db.lessons
    .filter(l => l.courseId === courseId)
    .sort((a, b) => (a.order || 0) - (b.order || 0));
  res.json(lessons);
});

app.post('/api/courses/:id/lessons', requireRole(['admin', 'profesor']), (req, res) => {
  const courseId = Number(req.params.id);
  const { title, type, url, order, quiz } = req.body;
  if (!title || !type) {
    return res.status(400).json({ error: "title y type son obligatorios" });
  }
  const lesson = {
    id: getNextId(db.lessons),
    courseId,
    title,
    type,
    url: url || "",
    order: Number(order) || db.lessons.filter(l => l.courseId === courseId).length + 1
  };
  if (type === "quiz" && quiz) {
    lesson.quiz = quiz;
  }
  db.lessons.push(lesson);
  saveData(db);
  res.status(201).json(lesson);
});

// --------------------- STUDENTS ---------------------
app.get('/api/students', (req, res) => {
  res.json(db.students);
});

app.post('/api/students', requireRole(['admin']), (req, res) => {
  const { name, email } = req.body;
  if (!name || !email) return res.status(400).json({ error: "name y email son obligatorios" });
  const student = {
    id: getNextId(db.students),
    name,
    email
  };
  db.students.push(student);
  saveData(db);
  res.status(201).json(student);
});

// --------------------- ENROLLMENTS ---------------------
app.get('/api/enrollments', (req, res) => {
  const enriched = db.enrollments.map(e => {
    const student = db.students.find(s => s.id === e.studentId);
    const course = db.courses.find(c => c.id === e.courseId);
    return {
      ...e,
      studentName: student ? student.name : "Estudiante",
      courseTitle: course ? course.title : "Curso",
      totalLessons: course ? (course.totalLessons || 0) : 0
    };
  });
  res.json(enriched);
});

app.post('/api/enrollments', requireRole(['admin', 'profesor']), (req, res) => {
  const { studentId, courseId } = req.body;
  if (!studentId || !courseId) {
    return res.status(400).json({ error: "studentId y courseId son obligatorios" });
  }
  const enrollment = {
    id: getNextId(db.enrollments),
    studentId: Number(studentId),
    courseId: Number(courseId),
    completedLessons: 0,
    enrolledAt: new Date().toISOString().slice(0, 10),
    lessonProgress: []
  };
  db.enrollments.push(enrollment);
  saveData(db);
  res.status(201).json(enrollment);
});

// actualizar progreso numérico manual (opcional)
app.post('/api/enrollments/:id/progress', (req, res) => {
  const id = Number(req.params.id);
  const { completedLessons } = req.body;
  const enrollment = db.enrollments.find(e => e.id === id);
  if (!enrollment) return res.status(404).json({ error: "inscripción no encontrada" });
  enrollment.completedLessons = Number(completedLessons);
  saveData(db);
  res.json(enrollment);
});

// registrar resultado de quiz de una lección
app.post('/api/enrollments/:id/quiz-result', (req, res) => {
  const id = Number(req.params.id);
  const { lessonId, correct } = req.body;

  const enrollment = db.enrollments.find(e => e.id === id);
  if (!enrollment) return res.status(404).json({ error: "inscripción no encontrada" });

  ensureLessonProgressArray(enrollment);

  const lid = Number(lessonId);
  const score = correct ? 100 : 0;

  let lp = enrollment.lessonProgress.find(p => p.lessonId === lid);
  if (lp) {
    lp.completed = true;
    lp.score = score;
  } else {
    enrollment.lessonProgress.push({
      lessonId: lid,
      completed: true,
      score
    });
  }

  // actualizar contador de lecciones completadas
  enrollment.completedLessons = enrollment.lessonProgress.filter(p => p.completed).length;

  saveData(db);
  res.json(enrollment);
});

// detalle de progreso por lección + score final
app.get('/api/enrollments/:id/detail', (req, res) => {
  const id = Number(req.params.id);
  const enrollment = db.enrollments.find(e => e.id === id);
  if (!enrollment) return res.status(404).json({ error: "inscripción no encontrada" });

  const course = db.courses.find(c => c.id === enrollment.courseId);
  const lessons = db.lessons
    .filter(l => l.courseId === enrollment.courseId)
    .sort((a, b) => (a.order || 0) - (b.order || 0));

  ensureLessonProgressArray(enrollment);
  const lpMap = new Map(enrollment.lessonProgress.map(p => [p.lessonId, p]));

  const lessonDetails = lessons.map(l => {
    const prog = lpMap.get(l.id) || { completed: false, score: null };
    return {
      id: l.id,
      title: l.title,
      type: l.type,
      order: l.order,
      completed: !!prog.completed,
      score: prog.score
    };
  });

  const totalLessons = course ? (course.totalLessons || lessonDetails.length) : lessonDetails.length;
  const completedCount = lessonDetails.filter(l => l.completed).length;
  const percentComplete = totalLessons
    ? Math.round((completedCount / totalLessons) * 100)
    : 0;

  const quizLessons = lessonDetails.filter(l => l.type === "quiz");
  let finalQuizScore = null;
  if (quizLessons.length) {
    const sum = quizLessons.reduce((acc, l) => {
      return acc + (typeof l.score === "number" ? l.score : 0);
    }, 0);
    finalQuizScore = Math.round(sum / quizLessons.length);
  }

  res.json({
    enrollmentId: enrollment.id,
    studentId: enrollment.studentId,
    courseId: enrollment.courseId,
    courseTitle: course ? course.title : "Curso",
    percentComplete,
    finalQuizScore,
    lessons: lessonDetails
  });
});

// --------------------- CERTIFICATES ---------------------
app.get('/api/certificates', (req, res) => {
  const enriched = db.certificates.map(c => {
    const enrollment = db.enrollments.find(e => e.id === c.enrollmentId);
    const student = enrollment ? db.students.find(s => s.id === enrollment.studentId) : null;
    const course = enrollment ? db.courses.find(co => co.id === enrollment.courseId) : null;
    return {
      ...c,
      studentName: student ? student.name : "Estudiante",
      courseTitle: course ? course.title : "Curso"
    };
  });
  res.json(enriched);
});

app.post('/api/certificates/generate', requireRole(['admin', 'profesor']), (req, res) => {
  const { enrollmentId } = req.body;
  if (!enrollmentId) return res.status(400).json({ error: "enrollmentId es obligatorio" });

  const enrollment = db.enrollments.find(e => e.id === Number(enrollmentId));
  if (!enrollment) return res.status(404).json({ error: "inscripción no encontrada" });

  const course = db.courses.find(c => c.id === enrollment.courseId);
  if (!course) return res.status(404).json({ error: "curso no encontrado" });

  if (enrollment.completedLessons < (course.totalLessons || 1)) {
    return res.status(400).json({ error: "el curso aún no está completado" });
  }

  const existing = db.certificates.find(c => c.enrollmentId === enrollment.id);
  if (existing) {
    return res.json(existing);
  }

  const cert = {
    id: getNextId(db.certificates),
    enrollmentId: enrollment.id,
    issuedAt: new Date().toISOString().slice(0, 10),
    code: "CERT-" + String(getNextId(db.certificates)).padStart(4, "0")
  };
  db.certificates.push(cert);
  saveData(db);
  res.status(201).json(cert);
});

// PDF
app.get('/api/certificates/:id/pdf', (req, res) => {
  const certId = Number(req.params.id);
  const cert = db.certificates.find(c => c.id === certId);
  if (!cert) return res.status(404).json({ error: "certificado no encontrado" });

  const enrollment = db.enrollments.find(e => e.id === cert.enrollmentId);
  const student = enrollment ? db.students.find(s => s.id === enrollment.studentId) : null;
  const course = enrollment ? db.courses.find(co => co.id === enrollment.courseId) : null;

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="certificado-${cert.code}.pdf"`);

  const doc = new PDFDocument({ margin: 50 });
  doc.pipe(res);

  doc.fontSize(22).text("Certificado de Finalización", { align: "center" });
  doc.moveDown(2);
  doc.fontSize(14).text("Se certifica que", { align: "center" });
  doc.moveDown(1);
  doc.fontSize(18).text(student ? student.name : "Estudiante", { align: "center" });
  doc.moveDown(1.5);
  doc.fontSize(14).text("ha completado satisfactoriamente el curso", { align: "center" });
  doc.moveDown(1);
  doc.fontSize(16).text(course ? course.title : "Curso", { align: "center" });
  doc.moveDown(2);
  doc.fontSize(12).text(`Código de certificado: ${cert.code}`, { align: "center" });
  doc.moveDown(1);
  doc.text(`Fecha de emisión: ${cert.issuedAt}`, { align: "center" });

  doc.end();
});

// email (texto simple)
app.post('/api/certificates/:id/email', async (req, res) => {
  const certId = Number(req.params.id);
  const { to } = req.body;
  if (!to) return res.status(400).json({ error: "campo 'to' es obligatorio" });

  const cert = db.certificates.find(c => c.id === certId);
  if (!cert) return res.status(404).json({ error: "certificado no encontrado" });

  const enrollment = db.enrollments.find(e => e.id === cert.enrollmentId);
  const student = enrollment ? db.students.find(s => s.id === enrollment.studentId) : null;
  const course = enrollment ? db.courses.find(co => co.id === enrollment.courseId) : null;

  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    return res.status(500).json({
      error: "SMTP no configurado. Define SMTP_HOST, SMTP_PORT, SMTP_USER y SMTP_PASS en variables de entorno."
    });
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });

  const info = await transporter.sendMail({
    from: process.env.SMTP_USER,
    to,
    subject: `Certificado ${cert.code}`,
    text: `Hola,\n\nDatos de tu certificado:\n\nEstudiante: ${student ? student.name : "Estudiante"}\nCurso: ${course ? course.title : "Curso"}\nCódigo: ${cert.code}\nFecha: ${cert.issuedAt}\n\n(En este ejemplo solo se envía texto, puedes extenderlo para adjuntar el PDF).`
  });

  res.json({ message: "Correo enviado (si SMTP está bien configurado)", id: info.messageId });
});

// --------------------- STATS ---------------------
app.get('/api/stats/overview', (req, res) => {
  const totalCourses = db.courses.length;
  const totalStudents = db.students.length;
  const totalEnrollments = db.enrollments.length;
  const totalCertificates = db.certificates.length;

  res.json({
    totalCourses,
    totalStudents,
    totalEnrollments,
    totalCertificates
  });
});

app.get('/api/stats/enrollments-by-course', (req, res) => {
  const result = db.courses.map(c => {
    const count = db.enrollments.filter(e => e.courseId === c.id).length;
    return {
      courseId: c.id,
      title: c.title,
      enrollments: count
    };
  });
  res.json(result);
});

app.get('/api/stats/course-progress', (req, res) => {
  const result = db.courses.map(c => {
    const related = db.enrollments.filter(e => e.courseId === c.id);
    if (!related.length) {
      return { courseId: c.id, title: c.title, avgCompletion: 0 };
    }
    const sumPercent = related.reduce((sum, e) => {
      const totalLessons = c.totalLessons || 1;
      const pct = totalLessons ? (e.completedLessons / totalLessons) * 100 : 0;
      return sum + pct;
    }, 0);
    return {
      courseId: c.id,
      title: c.title,
      avgCompletion: Math.round(sumPercent / related.length)
    };
  });
  res.json(result);
});

// fallback SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Plataforma educativa optimizada escuchando en http://localhost:${PORT}`);
});
