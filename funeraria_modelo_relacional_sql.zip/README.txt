
MODELO RELACIONAL FUNERARIA - SQL

Archivos:
- schema.sql -> CREATE TABLE de users, clients, locations, bodies.
- seed.sql   -> INSERTs de ejemplo (usuarios, clientes, ubicaciones, cuerpos).

Cómo usar (PostgreSQL):
1. Crear base de datos, por ejemplo:
   CREATE DATABASE funeraria_db;

2. Conectarte a la BD:
   \c funeraria_db;

3. Ejecutar el esquema:
   \i schema.sql;

4. Cargar datos de ejemplo:
   \i seed.sql;
