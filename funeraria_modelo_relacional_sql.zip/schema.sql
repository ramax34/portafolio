
-- MODELO RELACIONAL FUNERARIA
-- Esquema básico en PostgreSQL (compatible con la mayoría de motores)

CREATE TABLE users (
    id              SERIAL PRIMARY KEY,
    name            VARCHAR(100) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'operador', 'consulta')),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE clients (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(150) NOT NULL,
    phone       VARCHAR(30),
    email       VARCHAR(150),
    created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE locations (
    id          SERIAL PRIMARY KEY,
    code        VARCHAR(50) NOT NULL UNIQUE,  -- ej: BOD-01, SALA-1, CEM-PA-01
    type        VARCHAR(50) NOT NULL,         -- ej: Sala de velación, Bodega frío
    description TEXT
);

CREATE TABLE bodies (
    id              SERIAL PRIMARY KEY,
    code            VARCHAR(50) NOT NULL UNIQUE,   -- ej: CB-0001
    full_name       VARCHAR(150) NOT NULL,
    id_number       VARCHAR(50),                   -- documento
    date_of_death   DATE NOT NULL,
    status          VARCHAR(50) NOT NULL,          -- ej: En preparación, En sala de velación
    location_id     INTEGER NOT NULL REFERENCES locations(id),
    client_id       INTEGER REFERENCES clients(id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
