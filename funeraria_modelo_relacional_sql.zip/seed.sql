
-- DATOS DE EJEMPLO PARA LA FUNERARIA

-- Usuarios demo (en un sistema real, password_hash debería llevar hash, no texto plano)
INSERT INTO users (name, email, password_hash, role)
VALUES
('Admin',    'admin@funeraria.local',    'admin123',    'admin'),
('Operador', 'operador@funeraria.local', 'oper123',     'operador'),
('Consulta', 'consulta@funeraria.local', 'consulta123', 'consulta');

-- Clientes
INSERT INTO clients (name, phone, email) VALUES
('Familia García', '3001234567', 'familia.garcia@example.com'),
('Familia Pérez',  '3009876543', 'familia.perez@example.com');

-- Ubicaciones
INSERT INTO locations (code, type, description) VALUES
('SALA-1',    'Sala de velación', 'Sala principal'),
('BOD-01',    'Bodega frío',      'Cámara de frío 1'),
('CEM-PA-01', 'Cementerio',       'Pabellón A - Nicho 01');

-- Cuerpos
INSERT INTO bodies (code, full_name, id_number, date_of_death, status, location_id, client_id)
VALUES
('CB-0001', 'Persona Ejemplo 1', 'CC123456', '2025-01-10', 'En preparación',       2, 1),
('CB-0002', 'Persona Ejemplo 2', 'CC654321', '2025-02-03', 'En sala de velación',  1, 2);
