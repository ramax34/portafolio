
const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3001;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data.json');

// -------------------- CARGA Y GUARDADO --------------------
function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    const seed = {
      locations: [
        { id: 1, code: "SALA-1", type: "Sala de velación", description: "Sala principal" },
        { id: 2, code: "BOD-01", type: "Bodega frío", description: "Cámara de frío 1" },
        { id: 3, code: "CEM-PA-01", type: "Cementerio", description: "Pabellón A - Nicho 01" }
      ],
      clients: [
        { id: 1, name: "Familia García", phone: "3001234567", email: "familia.garcia@example.com" },
        { id: 2, name: "Familia Pérez", phone: "3009876543", email: "familia.perez@example.com" }
      ],
      bodies: [
        {
          id: 1,
          fullName: "Persona Ejemplo 1",
          idNumber: "CC123456",
          dateOfDeath: "2025-01-10",
          status: "En preparación",
          locationId: 2,
          clientId: 1,
          code: "CB-0001"
        },
        {
          id: 2,
          fullName: "Persona Ejemplo 2",
          idNumber: "CC654321",
          dateOfDeath: "2025-02-03",
          status: "En sala de velación",
          locationId: 1,
          clientId: 2,
          code: "CB-0002"
        }
      ],
      users: [
        { id: 1, name: "Admin", email: "admin@funeraria.local", password: "admin123", role: "admin" },
        { id: 2, name: "Operador", email: "operador@funeraria.local", password: "oper123", role: "operador" },
        { id: 3, name: "Consulta", email: "consulta@funeraria.local", password: "consulta123", role: "consulta" }
      ]
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(seed, null, 2), 'utf8');
    return seed;
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(raw);
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

let db = loadData();

function getNextId(list) {
  if (!list.length) return 1;
  return Math.max(...list.map(i => i.id)) + 1;
}

// -------------------- AUTH SIMPLE --------------------
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email && u.password === password);
  if (!user) {
    return res.status(401).json({ error: "Credenciales inválidas" });
  }
  const token = "demo-" + user.id + "-" + Date.now();
  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role
    }
  });
});

function requireRole(roles) {
  return (req, res, next) => {
    const role = req.headers['x-role'];
    if (!role || !roles.includes(role)) {
      return res.status(403).json({ error: "No autorizado" });
    }
    next();
  };
}

// -------------------- LOCATIONS --------------------
app.get('/api/locations', (req, res) => {
  res.json(db.locations);
});

app.post('/api/locations', requireRole(['admin']), (req, res) => {
  const { code, type, description } = req.body;
  if (!code || !type) {
    return res.status(400).json({ error: "code y type son obligatorios" });
  }
  const loc = {
    id: getNextId(db.locations),
    code,
    type,
    description: description || ""
  };
  db.locations.push(loc);
  saveData(db);
  res.status(201).json(loc);
});

// -------------------- CLIENTS --------------------
app.get('/api/clients', (req, res) => {
  res.json(db.clients);
});

app.post('/api/clients', requireRole(['admin', 'operador']), (req, res) => {
  const { name, phone, email } = req.body;
  if (!name) return res.status(400).json({ error: "name es obligatorio" });
  const client = {
    id: getNextId(db.clients),
    name,
    phone: phone || "",
    email: email || ""
  };
  db.clients.push(client);
  saveData(db);
  res.status(201).json(client);
});

// -------------------- BODIES --------------------
app.get('/api/bodies', (req, res) => {
  const enriched = db.bodies.map(b => {
    const loc = db.locations.find(l => l.id === b.locationId);
    const client = db.clients.find(c => c.id === b.clientId);
    return {
      ...b,
      locationCode: loc ? loc.code : null,
      locationType: loc ? loc.type : null,
      clientName: client ? client.name : null
    };
  });
  res.json(enriched);
});

app.post('/api/bodies', requireRole(['admin', 'operador']), (req, res) => {
  const { fullName, idNumber, dateOfDeath, status, locationId, clientId } = req.body;
  if (!fullName || !dateOfDeath || !locationId) {
    return res.status(400).json({ error: "fullName, dateOfDeath y locationId son obligatorios" });
  }
  const nextId = getNextId(db.bodies);
  const body = {
    id: nextId,
    fullName,
    idNumber: idNumber || "",
    dateOfDeath,
    status: status || "Registrado",
    locationId: Number(locationId),
    clientId: clientId ? Number(clientId) : null,
    code: "CB-" + String(nextId).padStart(4, "0")
  };
  db.bodies.push(body);
  saveData(db);
  res.status(201).json(body);
});

app.put('/api/bodies/:id/location', requireRole(['admin', 'operador']), (req, res) => {
  const id = Number(req.params.id);
  const { locationId, status } = req.body;
  const body = db.bodies.find(b => b.id === id);
  if (!body) return res.status(404).json({ error: "registro no encontrado" });
  if (locationId) body.locationId = Number(locationId);
  if (status) body.status = status;
  saveData(db);
  res.json(body);
});

// -------------------- STATS / DASHBOARD --------------------
app.get('/api/stats/overview', (req, res) => {
  const totalBodies = db.bodies.length;
  const totalClients = db.clients.length;
  const totalLocations = db.locations.length;

  const byStatus = {};
  db.bodies.forEach(b => {
    byStatus[b.status] = (byStatus[b.status] || 0) + 1;
  });

  const byLocationType = {};
  db.bodies.forEach(b => {
    const loc = db.locations.find(l => l.id === b.locationId);
    const type = loc ? loc.type : "Sin asignar";
    byLocationType[type] = (byLocationType[type] || 0) + 1;
  });

  res.json({
    totalBodies,
    totalClients,
    totalLocations,
    byStatus,
    byLocationType
  });
});

// -------------------- BACKUP SIMPLE --------------------
app.get('/api/backup', requireRole(['admin']), (req, res) => {
  const backup = {
    createdAt: new Date().toISOString(),
    data: db
  };
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename="backup-funeraria.json"');
  res.send(JSON.stringify(backup, null, 2));
});

// -------------------- SPA FALLBACK --------------------
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Funeraria DB Dashboard escuchando en http://localhost:${PORT}`);
});
