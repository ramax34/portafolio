
const API_BASE = "";
let currentUser = null;

// ---------- helpers ----------
function formToJSON(form) {
  const data = new FormData(form);
  return Object.fromEntries(data.entries());
}

function authHeaders() {
  if (!currentUser) return {};
  return { "x-role": currentUser.role };
}

// ---------- login ----------
const loginScreen = document.getElementById("login-screen");
const appRoot = document.getElementById("app-root");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.style.display = "none";
  const payload = formToJSON(loginForm);
  try {
    const res = await fetch(API_BASE + "/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      loginError.style.display = "block";
      return;
    }
    const data = await res.json();
    currentUser = data.user;
    localStorage.setItem("funerariaUser", JSON.stringify(currentUser));
    enterApp();
  } catch {
    loginError.style.display = "block";
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  localStorage.removeItem("funerariaUser");
  currentUser = null;
  location.reload();
});

function enterApp() {
  loginScreen.style.display = "none";
  appRoot.style.display = "block";
  document.getElementById("user-name").textContent = currentUser.name;
  document.getElementById("user-role").textContent = currentUser.role;
  adjustUIForRole();
  initApp();
}

const stored = localStorage.getItem("funerariaUser");
if (stored) {
  currentUser = JSON.parse(stored);
  enterApp();
}

function adjustUIForRole() {
  if (!currentUser) return;
  const role = currentUser.role;

  const formBody = document.getElementById("form-body");
  const formLocation = document.getElementById("form-location");
  const formClient = document.getElementById("form-client");
  const backupBtn = document.getElementById("btn-backup");

  if (role === "consulta") {
    if (formBody) formBody.style.display = "none";
    if (formLocation) formLocation.style.display = "none";
    if (formClient) formClient.style.display = "none";
  } else if (role === "operador") {
    if (formLocation) formLocation.style.display = "none";
  }

  if (backupBtn) {
    backupBtn.style.display = role === "admin" ? "inline-flex" : "none";
  }
}

// ---------- tabs ----------
const tabs = document.querySelectorAll(".tab");
const views = {
  dashboard: document.getElementById("view-dashboard"),
  cuerpos: document.getElementById("view-cuerpos"),
  ubicaciones: document.getElementById("view-ubicaciones"),
  clientes: document.getElementById("view-clientes"),
};

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const view = tab.dataset.view;
    tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    Object.keys(views).forEach((key) => {
      views[key].style.display = key === view ? "block" : "none";
    });
  });
});

// ---------- dashboard ----------
let chartStatus = null;
let chartLocType = null;

async function loadOverview() {
  const res = await fetch(API_BASE + "/api/stats/overview");
  const data = await res.json();
  document.getElementById("kpi-total-bodies").textContent = data.totalBodies;
  document.getElementById("kpi-total-clients").textContent = data.totalClients;
  document.getElementById("kpi-total-locations").textContent = data.totalLocations;

  const statusLabels = Object.keys(data.byStatus);
  const statusValues = Object.values(data.byStatus);
  const ctxStatus = document.getElementById("chart-status").getContext("2d");

  if (chartStatus) chartStatus.destroy();
  chartStatus = new Chart(ctxStatus, {
    type: "bar",
    data: {
      labels: statusLabels,
      datasets: [{ label: "Cuerpos", data: statusValues }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false }, ticks: { color: "#9ca3af" } },
        y: { grid: { color: "rgba(55,65,81,0.6)" }, ticks: { color: "#9ca3af" } },
      },
      plugins: { legend: { labels: { color: "#e5e7eb" } } },
    },
  });

  const locLabels = Object.keys(data.byLocationType);
  const locValues = Object.values(data.byLocationType);
  const ctxLoc = document.getElementById("chart-location-type").getContext("2d");

  if (chartLocType) chartLocType.destroy();
  chartLocType = new Chart(ctxLoc, {
    type: "pie",
    data: {
      labels: locLabels,
      datasets: [{ data: locValues }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: "#e5e7eb" } },
      },
    },
  });
}

// backup
document.getElementById("btn-backup").addEventListener("click", () => {
  if (!currentUser || currentUser.role !== "admin") {
    alert("Solo admin puede descargar backups.");
    return;
  }
  window.open("/api/backup", "_blank");
});

// ---------- ubicaciones ----------
async function loadLocations() {
  const res = await fetch(API_BASE + "/api/locations");
  const locations = await res.json();
  const list = document.getElementById("locations-list");
  list.innerHTML = "";

  locations.forEach((l) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${l.code}</div>
          <div class="list-item-meta">${l.type}</div>
        </div>
      </div>
      <div class="list-item-meta">${l.description || ""}</div>
    `;
    list.appendChild(item);
  });

  const bodyLocationSelect = document.getElementById("body-location-select");
  bodyLocationSelect.innerHTML = "";
  locations.forEach((l) => {
    const opt = document.createElement("option");
    opt.value = l.id;
    opt.textContent = `${l.code} (${l.type})`;
    bodyLocationSelect.appendChild(opt);
  });
}

function setupLocationForm() {
  const form = document.getElementById("form-location");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/locations", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar ubicación (solo admin).");
      return;
    }
    form.reset();
    await Promise.all([loadLocations(), loadOverview()]);
  });
}

// ---------- clientes ----------
async function loadClients() {
  const res = await fetch(API_BASE + "/api/clients");
  const clients = await res.json();
  const list = document.getElementById("clients-list");
  list.innerHTML = "";

  clients.forEach((c) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${c.name}</div>
          <div class="list-item-meta">Tel: ${c.phone || "-"} · ${c.email || "-"}</div>
        </div>
      </div>
    `;
    list.appendChild(item);
  });

  const bodyClientSelect = document.getElementById("body-client-select");
  bodyClientSelect.innerHTML = '<option value="">Sin asignar</option>';
  clients.forEach((c) => {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = c.name;
    bodyClientSelect.appendChild(opt);
  });
}

function setupClientForm() {
  const form = document.getElementById("form-client");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/clients", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar cliente (admin / operador).");
      return;
    }
    form.reset();
    await Promise.all([loadClients(), loadOverview()]);
  });
}

// ---------- cuerpos ----------
async function loadBodies() {
  const res = await fetch(API_BASE + "/api/bodies");
  const bodies = await res.json();
  const list = document.getElementById("bodies-list");
  list.innerHTML = "";

  bodies.forEach((b) => {
    const item = document.createElement("div");
    item.className = "list-item";
    const metaLines = [
      `Documento: ${b.idNumber || "-"}`,
      `Fecha fallecimiento: ${b.dateOfDeath}`,
      `Ubicación: ${b.locationCode || "-"} (${b.locationType || "-"})`,
      `Cliente: ${b.clientName || "-"}`
    ];
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${b.fullName}</div>
          <div class="list-item-meta">Código: ${b.code} · Estado: ${b.status}</div>
        </div>
      </div>
      <div class="list-item-meta">${metaLines.join(" · ")}</div>
    `;
    list.appendChild(item);
  });
}

function setupBodyForm() {
  const form = document.getElementById("form-body");
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/bodies", {
      method: "POST",
      headers: { "Content-Type": "application/json", ...authHeaders() },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al registrar (verifica permisos y campos obligatorios).");
      return;
    }
    form.reset();
    await Promise.all([loadBodies(), loadOverview()]);
  });
}

// ---------- init ----------
async function initApp() {
  await Promise.all([
    loadOverview(),
    loadLocations(),
    loadClients(),
    loadBodies(),
  ]);

  setupLocationForm();
  setupClientForm();
  setupBodyForm();
}
