
const API_BASE = "";

// Utilidad simple para formData -> objeto
function formToJSON(form) {
  const data = new FormData(form);
  return Object.fromEntries(data.entries());
}

// ====================
// Navegación por tabs
// ====================
const tabs = document.querySelectorAll(".tab");
const views = {
  dashboard: document.getElementById("view-dashboard"),
  clientes: document.getElementById("view-clientes"),
  proyectos: document.getElementById("view-proyectos"),
  actividades: document.getElementById("view-actividades"),
};

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const view = tab.dataset.view;
    tabs.forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    Object.keys(views).forEach((key) => {
      views[key].style.display = key === view ? "block" : "none";
    });
  });
});

// ====================
// Dashboard / KPIs
// ====================
let chartMonthly = null;
let chartStatus = null;

async function loadOverview() {
  const res = await fetch(API_BASE + "/api/stats/overview");
  const data = await res.json();

  document.getElementById("kpi-total-clients").textContent = data.totalClients;
  document.getElementById("kpi-total-projects").textContent = data.totalProjects;
  document.getElementById("kpi-active-projects").textContent = data.activeProjects;
  document.getElementById("kpi-total-value").textContent = data.totalValue.toLocaleString("es-ES", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  });
}

async function loadMonthlyChart() {
  const res = await fetch(API_BASE + "/api/stats/monthly-revenue");
  const data = await res.json();
  const ctx = document.getElementById("chart-monthly").getContext("2d");

  if (chartMonthly) chartMonthly.destroy();

  chartMonthly = new Chart(ctx, {
    type: "line",
    data: {
      labels: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"],
      datasets: [
        {
          label: "Valor proyectos",
          data,
          tension: 0.35,
          borderWidth: 2,
          pointRadius: 3,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: "#9ca3af" },
        },
        y: {
          grid: { color: "rgba(55, 65, 81, 0.6)" },
          ticks: { color: "#9ca3af" },
        },
      },
      plugins: {
        legend: {
          labels: { color: "#e5e7eb" },
        },
      },
    },
  });
}

async function loadStatusChart() {
  const res = await fetch(API_BASE + "/api/stats/projects-by-status");
  const data = await res.json();
  const ctx = document.getElementById("chart-status").getContext("2d");

  if (chartStatus) chartStatus.destroy();

  chartStatus = new Chart(ctx, {
    type: "bar",
    data: {
      labels: data.map((d) => d.status.replace("_", " ")),
      datasets: [
        {
          label: "Proyectos",
          data: data.map((d) => d.count),
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: "#9ca3af" },
        },
        y: {
          grid: { color: "rgba(55, 65, 81, 0.6)" },
          ticks: { color: "#9ca3af" },
        },
      },
      plugins: {
        legend: {
          labels: { color: "#e5e7eb" },
        },
      },
    },
  });
}

// ====================
// Clientes
// ====================
async function loadClients() {
  const res = await fetch(API_BASE + "/api/clients");
  const clients = await res.json();

  const list = document.getElementById("clients-list");
  list.innerHTML = "";
  clients.forEach((c) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${c.name}</div>
          <div class="list-item-meta">${c.email} · ${c.phone || ""}</div>
        </div>
        <span class="badge">${c.status}</span>
      </div>
      <div class="list-item-meta">Industria: ${c.industry || "Sin definir"} · Desde: ${c.createdAt}</div>
    `;
    list.appendChild(item);
  });

  // actualizar selects dependientes
  const projectClientSelect = document.getElementById("project-client-select");
  const activityClientSelect = document.getElementById("activity-client-select");
  projectClientSelect.innerHTML = "";
  activityClientSelect.innerHTML = "";

  clients.forEach((c) => {
    const opt1 = document.createElement("option");
    opt1.value = c.id;
    opt1.textContent = c.name;
    projectClientSelect.appendChild(opt1);

    const opt2 = document.createElement("option");
    opt2.value = c.id;
    opt2.textContent = c.name;
    activityClientSelect.appendChild(opt2);
  });
}

async function setupClientForm() {
  const form = document.getElementById("form-client");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/clients", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar cliente");
      return;
    }
    form.reset();
    await Promise.all([loadClients(), loadOverview()]);
  });
}

// ====================
// Proyectos
// ====================
async function loadProjects() {
  const res = await fetch(API_BASE + "/api/projects");
  const projects = await res.json();

  const tbody = document.getElementById("projects-table-body");
  tbody.innerHTML = "";

  projects.forEach((p) => {
    const tr = document.createElement("tr");
    const value = (p.value || 0).toLocaleString("es-ES", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    });

    tr.innerHTML = `
      <td>${p.name}</td>
      <td>${p.clientName}</td>
      <td><span class="badge badge-status-${p.status}">${p.status.replace("_", " ")}</span></td>
      <td>${value}</td>
    `;
    tbody.appendChild(tr);
  });

  // actualizar selects de actividades (proyectos)
  const activityProjectSelect = document.getElementById("activity-project-select");
  activityProjectSelect.innerHTML = '<option value="">Sin proyecto</option>';
  projects.forEach((p) => {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = p.name;
    activityProjectSelect.appendChild(opt);
  });
}

async function setupProjectForm() {
  const form = document.getElementById("form-project");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar proyecto");
      return;
    }
    form.reset();
    await Promise.all([loadProjects(), loadOverview(), loadMonthlyChart(), loadStatusChart()]);
  });
}

// ====================
// Actividades
// ====================
async function loadActivities() {
  const res = await fetch(API_BASE + "/api/activities");
  const activities = await res.json();
  const list = document.getElementById("activities-list");
  list.innerHTML = "";

  activities
    .sort((a, b) => (a.date > b.date ? -1 : 1))
    .forEach((a) => {
      const item = document.createElement("div");
      item.className = "list-item";
      item.innerHTML = `
        <div class="list-item-header">
          <div>
            <div class="list-item-title">${a.title}</div>
            <div class="list-item-meta">${a.clientName} · ${a.projectName}</div>
          </div>
          <span class="badge">${a.type}</span>
        </div>
        <div class="list-item-meta">${a.date} · ${a.notes || ""}</div>
      `;
      list.appendChild(item);
    });
}

async function setupActivityForm() {
  const form = document.getElementById("form-activity");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    const res = await fetch(API_BASE + "/api/activities", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("Error al guardar actividad");
      return;
    }
    form.reset();
    await loadActivities();
  });
}

// ====================
// Inicialización
// ====================
async function init() {
  await Promise.all([
    loadOverview(),
    loadMonthlyChart(),
    loadStatusChart(),
    loadClients(),
    loadProjects(),
    loadActivities(),
  ]);
  setupClientForm();
  setupProjectForm();
  setupActivityForm();
}

document.addEventListener("DOMContentLoaded", init);
