
const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares
app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data.json');

// Cargar datos iniciales o crear archivo por defecto
function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    const seed = {
      clients: [
        { id: 1, name: "Acme Corp", email: "contacto@acme.com", phone: "+52 555 111 2222", status: "activo", industry: "Tecnología", createdAt: "2025-01-10" },
        { id: 2, name: "Beta Solutions", email: "ventas@beta.com", phone: "+52 555 333 4444", status: "activo", industry: "Servicios", createdAt: "2025-02-05" },
        { id: 3, name: "Gamma Studio", email: "hola@gamma.com", phone: "+52 555 777 8888", status: "inactivo", industry: "Marketing", createdAt: "2025-03-01" }
      ],
      projects: [
        { id: 1, clientId: 1, name: "Implementación CRM", status: "en_progreso", value: 12000, startDate: "2025-02-01", endDate: "2025-06-30" },
        { id: 2, clientId: 2, name: "Sitio Web Corporativo", status: "completado", value: 8000, startDate: "2025-01-15", endDate: "2025-04-15" },
        { id: 3, clientId: 1, name: "Integración API", status: "propuesta", value: 5000, startDate: "2025-05-01", endDate: null }
      ],
      activities: [
        { id: 1, clientId: 1, projectId: 1, type: "llamada", title: "Llamada de kickoff", date: "2025-02-02", notes: "Definimos alcance y entregables" },
        { id: 2, clientId: 2, projectId: 2, type: "reunión", title: "Revisión de diseño", date: "2025-03-10", notes: "Feedback positivo" },
        { id: 3, clientId: 1, projectId: 3, type: "email", title: "Envío de propuesta", date: "2025-05-05", notes: "Esperando respuesta" }
      ]
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(seed, null, 2), 'utf8');
    return seed;
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(raw);
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

let db = loadData();

// Utilidad simple para ID incremental
function getNextId(list) {
  if (!list.length) return 1;
  return Math.max(...list.map(i => i.id)) + 1;
}

// =====================
// RUTAS API REST
// =====================

// Clientes
app.get('/api/clients', (req, res) => {
  res.json(db.clients);
});

app.post('/api/clients', (req, res) => {
  const { name, email, phone, status, industry } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: 'name y email son obligatorios' });
  }
  const client = {
    id: getNextId(db.clients),
    name,
    email,
    phone: phone || '',
    status: status || 'activo',
    industry: industry || '',
    createdAt: new Date().toISOString().slice(0, 10)
  };
  db.clients.push(client);
  saveData(db);
  res.status(201).json(client);
});

// Proyectos
app.get('/api/projects', (req, res) => {
  const projectsWithClient = db.projects.map(p => {
    const client = db.clients.find(c => c.id === p.clientId);
    return { ...p, clientName: client ? client.name : "Sin cliente" };
  });
  res.json(projectsWithClient);
});

app.post('/api/projects', (req, res) => {
  const { clientId, name, status, value, startDate, endDate } = req.body;
  if (!clientId || !name) {
    return res.status(400).json({ error: 'clientId y name son obligatorios' });
  }
  const project = {
    id: getNextId(db.projects),
    clientId: Number(clientId),
    name,
    status: status || 'propuesta',
    value: Number(value) || 0,
    startDate: startDate || new Date().toISOString().slice(0, 10),
    endDate: endDate || null
  };
  db.projects.push(project);
  saveData(db);
  res.status(201).json(project);
});

// Actividades
app.get('/api/activities', (req, res) => {
  const activitiesWithNames = db.activities.map(a => {
    const client = db.clients.find(c => c.id === a.clientId);
    const project = db.projects.find(p => p.id === a.projectId);
    return {
      ...a,
      clientName: client ? client.name : "Sin cliente",
      projectName: project ? project.name : "Sin proyecto"
    };
  });
  res.json(activitiesWithNames);
});

app.post('/api/activities', (req, res) => {
  const { clientId, projectId, type, title, date, notes } = req.body;
  if (!clientId || !type || !title) {
    return res.status(400).json({ error: 'clientId, type y title son obligatorios' });
  }
  const activity = {
    id: getNextId(db.activities),
    clientId: Number(clientId),
    projectId: projectId ? Number(projectId) : null,
    type,
    title,
    date: date || new Date().toISOString().slice(0, 10),
    notes: notes || ''
  };
  db.activities.push(activity);
  saveData(db);
  res.status(201).json(activity);
});

// Estadísticas / Dashboard
app.get('/api/stats/overview', (req, res) => {
  const totalClients = db.clients.length;
  const totalProjects = db.projects.length;
  const activeProjects = db.projects.filter(p => p.status === 'en_progreso').length;
  const proposals = db.projects.filter(p => p.status === 'propuesta').length;
  const completedProjects = db.projects.filter(p => p.status === 'completado').length;
  const totalValue = db.projects.reduce((sum, p) => sum + (p.value || 0), 0);

  res.json({
    totalClients,
    totalProjects,
    activeProjects,
    proposals,
    completedProjects,
    totalValue
  });
});

app.get('/api/stats/projects-by-status', (req, res) => {
  const statuses = ['propuesta', 'en_progreso', 'en_pausa', 'completado', 'cancelado'];
  const result = statuses.map(status => ({
    status,
    count: db.projects.filter(p => p.status === status).length
  }));
  res.json(result);
});

// Ventas mensuales (valor de proyectos según startDate)
app.get('/api/stats/monthly-revenue', (req, res) => {
  const monthly = Array(12).fill(0);
  db.projects.forEach(p => {
    if (!p.startDate) return;
    const monthIndex = new Date(p.startDate).getMonth();
    monthly[monthIndex] += p.value || 0;
  });
  res.json(monthly);
});

// Fallback para SPA / frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Servidor CRM escuchando en http://localhost:${PORT}`);
});
