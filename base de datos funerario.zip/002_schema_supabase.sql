-- ============================================================
--  SCHEMA POSTGRESQL / SUPABASE (NUBE)
--  Ejecuta esto en el SQL Editor de Supabase
-- ============================================================

-- Extensión para UUIDs reales
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ────────────────────────────────────────
-- TABLA: usuarios
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre          TEXT NOT NULL,
    apellido        TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    contrasena      TEXT NOT NULL,
    rol             TEXT NOT NULL DEFAULT 'empleado'
                        CHECK(rol IN ('admin','empleado','recepcion')),
    activo          BOOLEAN NOT NULL DEFAULT true,
    creado_en       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ultimo_acceso   TIMESTAMPTZ
);

-- ────────────────────────────────────────
-- TABLA: difuntos
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS difuntos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre          TEXT NOT NULL,
    apellido        TEXT NOT NULL,
    fecha_nacimiento DATE,
    fecha_defuncion DATE NOT NULL,
    causa_defuncion TEXT,
    documento_id    TEXT,
    registrado_por  UUID NOT NULL REFERENCES usuarios(id),
    creado_en       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────
-- TABLA: clientes
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clientes (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre      TEXT NOT NULL,
    apellido    TEXT NOT NULL,
    telefono    TEXT,
    email       TEXT,
    direccion   TEXT,
    relacion    TEXT,
    creado_en   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────
-- TABLA: servicios
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS servicios (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre      TEXT NOT NULL,
    descripcion TEXT,
    precio      NUMERIC(12,2) NOT NULL DEFAULT 0,
    categoria   TEXT NOT NULL DEFAULT 'general'
                    CHECK(categoria IN ('basico','intermedio','premium','adicional')),
    activo      BOOLEAN NOT NULL DEFAULT true,
    creado_en   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────
-- TABLA: contratos
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contratos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    numero          TEXT NOT NULL UNIQUE,
    difunto_id      UUID NOT NULL REFERENCES difuntos(id),
    cliente_id      UUID NOT NULL REFERENCES clientes(id),
    empleado_id     UUID NOT NULL REFERENCES usuarios(id),
    fecha_contrato  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    fecha_servicio  TIMESTAMPTZ,
    estado          TEXT NOT NULL DEFAULT 'pendiente'
                        CHECK(estado IN ('pendiente','en_proceso','completado','cancelado')),
    total           NUMERIC(12,2) NOT NULL DEFAULT 0,
    notas           TEXT
);

-- ────────────────────────────────────────
-- TABLA: contrato_servicios
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contrato_servicios (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contrato_id UUID NOT NULL REFERENCES contratos(id),
    servicio_id UUID NOT NULL REFERENCES servicios(id),
    cantidad    INTEGER NOT NULL DEFAULT 1,
    precio_unit NUMERIC(12,2) NOT NULL,
    subtotal    NUMERIC(12,2) NOT NULL
);

-- ────────────────────────────────────────
-- TABLA: pagos
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pagos (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contrato_id     UUID NOT NULL REFERENCES contratos(id),
    monto           NUMERIC(12,2) NOT NULL,
    metodo_pago     TEXT NOT NULL DEFAULT 'efectivo'
                        CHECK(metodo_pago IN ('efectivo','tarjeta','transferencia','cheque')),
    fecha_pago      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    registrado_por  UUID NOT NULL REFERENCES usuarios(id),
    comprobante     TEXT
);

-- ────────────────────────────────────────
-- TABLA: sesiones
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sesiones (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id  UUID NOT NULL REFERENCES usuarios(id),
    token       TEXT NOT NULL UNIQUE,
    expira_en   TIMESTAMPTZ NOT NULL,
    ip_origen   INET,
    creado_en   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ────────────────────────────────────────
-- ÍNDICES
-- ────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_usuarios_email    ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_contratos_estado  ON contratos(estado);
CREATE INDEX IF NOT EXISTS idx_contratos_difunto ON contratos(difunto_id);
CREATE INDEX IF NOT EXISTS idx_pagos_contrato    ON pagos(contrato_id);
CREATE INDEX IF NOT EXISTS idx_sesiones_token    ON sesiones(token);

-- ────────────────────────────────────────
-- ROW LEVEL SECURITY (RLS) - Seguridad extra
-- ────────────────────────────────────────
ALTER TABLE usuarios           ENABLE ROW LEVEL SECURITY;
ALTER TABLE difuntos           ENABLE ROW LEVEL SECURITY;
ALTER TABLE clientes           ENABLE ROW LEVEL SECURITY;
ALTER TABLE contratos          ENABLE ROW LEVEL SECURITY;
ALTER TABLE contrato_servicios ENABLE ROW LEVEL SECURITY;
ALTER TABLE pagos              ENABLE ROW LEVEL SECURITY;

-- Solo usuarios autenticados pueden leer
CREATE POLICY "solo_autenticados" ON usuarios
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "solo_autenticados_difuntos" ON difuntos
    FOR SELECT USING (auth.role() = 'authenticated');

CREATE POLICY "solo_autenticados_contratos" ON contratos
    FOR SELECT USING (auth.role() = 'authenticated');

-- Inserts y updates solo con sesión activa
CREATE POLICY "insert_autenticado" ON contratos
    FOR INSERT WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "update_autenticado" ON contratos
    FOR UPDATE USING (auth.role() = 'authenticated');

-- ────────────────────────────────────────
-- DATOS INICIALES - Servicios
-- ────────────────────────────────────────
INSERT INTO servicios (nombre, descripcion, precio, categoria) VALUES
    ('Servicio básico',        'Ataúd sencillo, velación 4h, traslado local',      1500000, 'basico'),
    ('Servicio intermedio',    'Ataúd estándar, velación 8h, traslado 50km',       2800000, 'intermedio'),
    ('Servicio premium',       'Ataúd premium, velación 24h, traslado ilimitado',  5000000, 'premium'),
    ('Cremación',              'Servicio completo de cremación con urna',           1200000, 'adicional'),
    ('Arreglo floral',         'Corona de flores naturales',                          250000, 'adicional'),
    ('Esquela en periódico',   'Publicación en diario local',                         150000, 'adicional'),
    ('Traslado aéreo',         'Traslado en avión nacional',                         3500000, 'adicional'),
    ('Sala VIP',               'Sala privada con comodidades especiales',             800000, 'adicional')
ON CONFLICT DO NOTHING;
