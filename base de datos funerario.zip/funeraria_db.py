"""
funeraria_db.py
---------------
Base de datos funeraria con soporte LOCAL (SQLite) y NUBE (Supabase).
Detecta automáticamente si hay conexión a internet.

Instalación:
    pip install bcrypt supabase python-dotenv PyJWT requests

Uso:
    from funeraria_db import FunerariaDB
    db = FunerariaDB()
    db.iniciar()
    db.crear_usuario("Ana", "García", "ana@funeraria.com", "MiClave123!")
"""

import sqlite3
import bcrypt
import jwt
import uuid
import socket
import os
import json
from datetime import datetime, timedelta
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────────────
# CONFIGURACIÓN
# ─────────────────────────────────────────────────────
class Config:
    DB_LOCAL_PATH   = os.getenv("DB_LOCAL_PATH", "funeraria.db")
    SUPABASE_URL    = os.getenv("SUPABASE_URL", "")
    SUPABASE_KEY    = os.getenv("SUPABASE_KEY", "")
    JWT_SECRET      = os.getenv("JWT_SECRET", "cambia-esta-clave-en-produccion-2024")
    JWT_EXPIRA_HORAS = int(os.getenv("JWT_EXPIRA_HORAS", "8"))
    BCRYPT_ROUNDS    = int(os.getenv("BCRYPT_ROUNDS", "12"))


# ─────────────────────────────────────────────────────
# VERIFICAR CONEXIÓN A INTERNET
# ─────────────────────────────────────────────────────
def hay_internet(host="8.8.8.8", puerto=53, timeout=2):
    """Comprueba si hay conexión a internet."""
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, puerto))
        return True
    except socket.error:
        return False


# ─────────────────────────────────────────────────────
# MÓDULO AUTH (local)
# ─────────────────────────────────────────────────────
class Auth:
    """Gestión de contraseñas y tokens JWT."""

    @staticmethod
    def hashear_contrasena(contrasena: str) -> str:
        """Convierte contraseña a hash bcrypt seguro."""
        if len(contrasena) < 8:
            raise ValueError("La contraseña debe tener mínimo 8 caracteres")
        sal = bcrypt.gensalt(rounds=Config.BCRYPT_ROUNDS)
        return bcrypt.hashpw(contrasena.encode(), sal).decode()

    @staticmethod
    def verificar_contrasena(contrasena: str, hash_guardado: str) -> bool:
        """Verifica si la contraseña coincide con el hash."""
        return bcrypt.checkpw(contrasena.encode(), hash_guardado.encode())

    @staticmethod
    def generar_token(usuario_id: str, email: str, rol: str) -> str:
        """Genera JWT firmado con expiración."""
        payload = {
            "sub":   usuario_id,
            "email": email,
            "rol":   rol,
            "iat":   datetime.utcnow(),
            "exp":   datetime.utcnow() + timedelta(hours=Config.JWT_EXPIRA_HORAS)
        }
        return jwt.encode(payload, Config.JWT_SECRET, algorithm="HS256")

    @staticmethod
    def verificar_token(token: str) -> dict:
        """Verifica y decodifica un JWT. Lanza excepción si es inválido."""
        try:
            return jwt.decode(token, Config.JWT_SECRET, algorithms=["HS256"])
        except jwt.ExpiredSignatureError:
            raise ValueError("La sesión ha expirado. Inicia sesión nuevamente.")
        except jwt.InvalidTokenError:
            raise ValueError("Token inválido.")


# ─────────────────────────────────────────────────────
# BASE DE DATOS LOCAL (SQLite)
# ─────────────────────────────────────────────────────
class DBLocal:
    """Conexión y operaciones con SQLite (sin internet)."""

    def __init__(self):
        self.ruta = Config.DB_LOCAL_PATH
        self.conexion = None

    def conectar(self):
        self.conexion = sqlite3.connect(self.ruta, check_same_thread=False)
        self.conexion.row_factory = sqlite3.Row
        self.conexion.execute("PRAGMA foreign_keys = ON")
        self.conexion.execute("PRAGMA journal_mode = WAL")  # Mejor rendimiento
        return self

    def ejecutar_schema(self):
        """Crea las tablas si no existen."""
        # Buscar en varias ubicaciones posibles
        posibles = [
            Path(__file__).parent.parent / "migrations" / "001_schema.sql",
            Path(__file__).parent / "migrations" / "001_schema.sql",
            Path("migrations") / "001_schema.sql",
        ]
        schema_path = next((p for p in posibles if p.exists()), None)
        if schema_path:
            with open(schema_path, "r", encoding="utf-8") as f:
                self.conexion.executescript(f.read())
        else:
            # Schema embebido de respaldo
            self._crear_tablas_basicas()
        self.conexion.commit()
        print("✓ Base de datos local inicializada")

    def _crear_tablas_basicas(self):
        self.conexion.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, apellido TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE, contrasena TEXT NOT NULL,
            rol TEXT NOT NULL DEFAULT 'empleado', activo INTEGER NOT NULL DEFAULT 1,
            creado_en TEXT NOT NULL DEFAULT (datetime('now')), ultimo_acceso TEXT
        );
        CREATE TABLE IF NOT EXISTS sesiones (
            id TEXT PRIMARY KEY, usuario_id TEXT NOT NULL, token TEXT NOT NULL UNIQUE,
            expira_en TEXT NOT NULL, ip_origen TEXT, creado_en TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS difuntos (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, apellido TEXT NOT NULL,
            fecha_nacimiento TEXT, fecha_defuncion TEXT NOT NULL, causa_defuncion TEXT,
            documento_id TEXT, registrado_por TEXT NOT NULL, creado_en TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (registrado_por) REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS clientes (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, apellido TEXT NOT NULL,
            telefono TEXT, email TEXT, direccion TEXT, relacion TEXT,
            creado_en TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS servicios (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, descripcion TEXT,
            precio REAL NOT NULL DEFAULT 0,
            categoria TEXT NOT NULL DEFAULT 'general', activo INTEGER NOT NULL DEFAULT 1,
            creado_en TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS contratos (
            id TEXT PRIMARY KEY, numero TEXT NOT NULL UNIQUE,
            difunto_id TEXT NOT NULL, cliente_id TEXT NOT NULL, empleado_id TEXT NOT NULL,
            fecha_contrato TEXT DEFAULT (datetime('now')), fecha_servicio TEXT,
            estado TEXT NOT NULL DEFAULT 'pendiente', total REAL NOT NULL DEFAULT 0, notas TEXT,
            FOREIGN KEY (difunto_id) REFERENCES difuntos(id),
            FOREIGN KEY (cliente_id) REFERENCES clientes(id),
            FOREIGN KEY (empleado_id) REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS contrato_servicios (
            id TEXT PRIMARY KEY, contrato_id TEXT NOT NULL, servicio_id TEXT NOT NULL,
            cantidad INTEGER NOT NULL DEFAULT 1, precio_unit REAL NOT NULL, subtotal REAL NOT NULL,
            FOREIGN KEY (contrato_id) REFERENCES contratos(id),
            FOREIGN KEY (servicio_id) REFERENCES servicios(id)
        );
        CREATE TABLE IF NOT EXISTS pagos (
            id TEXT PRIMARY KEY, contrato_id TEXT NOT NULL, monto REAL NOT NULL,
            metodo_pago TEXT NOT NULL DEFAULT 'efectivo',
            fecha_pago TEXT DEFAULT (datetime('now')), registrado_por TEXT NOT NULL, comprobante TEXT,
            FOREIGN KEY (contrato_id) REFERENCES contratos(id),
            FOREIGN KEY (registrado_por) REFERENCES usuarios(id)
        );
        INSERT OR IGNORE INTO servicios (id,nombre,descripcion,precio,categoria) VALUES
            ('svc-001','Servicio básico','Ataúd sencillo, velación 4h, traslado local',1500000,'basico'),
            ('svc-002','Servicio intermedio','Ataúd estándar, velación 8h, traslado 50km',2800000,'intermedio'),
            ('svc-003','Servicio premium','Ataúd premium, velación 24h, traslado ilimitado',5000000,'premium'),
            ('svc-004','Cremación','Servicio completo de cremación con urna',1200000,'adicional'),
            ('svc-005','Arreglo floral','Corona de flores naturales',250000,'adicional'),
            ('svc-006','Esquela en periódico','Publicación en diario local',150000,'adicional'),
            ('svc-007','Traslado aéreo','Traslado en avión nacional',3500000,'adicional'),
            ('svc-008','Sala VIP','Sala privada con comodidades especiales',800000,'adicional');
        INSERT OR IGNORE INTO usuarios (id,nombre,apellido,email,contrasena,rol) VALUES
            ('usr-admin-001','Administrador','Sistema','admin@funeraria.com',
             '$2b$12$KIX/p.yAu3vf5uQgYlSWEuz.eXP5Bw1Xx1BRx5wEdj5VZbJkCyMGm','admin');
        """)

    def cerrar(self):
        if self.conexion:
            self.conexion.close()

    def query(self, sql: str, params: tuple = ()) -> list:
        cur = self.conexion.execute(sql, params)
        return [dict(row) for row in cur.fetchall()]

    def ejecutar(self, sql: str, params: tuple = ()) -> str:
        """Ejecuta INSERT/UPDATE/DELETE. Retorna lastrowid."""
        cur = self.conexion.execute(sql, params)
        self.conexion.commit()
        return cur.lastrowid


# ─────────────────────────────────────────────────────
# BASE DE DATOS NUBE (Supabase)
# ─────────────────────────────────────────────────────
class DBNube:
    """Conexión con Supabase (PostgreSQL en la nube)."""

    def __init__(self):
        self.cliente = None

    def conectar(self):
        if not Config.SUPABASE_URL or not Config.SUPABASE_KEY:
            print("⚠ Variables SUPABASE_URL y SUPABASE_KEY no configuradas")
            return self
        try:
            from supabase import create_client
            self.cliente = create_client(Config.SUPABASE_URL, Config.SUPABASE_KEY)
            print("✓ Conectado a Supabase (nube)")
        except Exception as e:
            print(f"⚠ No se pudo conectar a Supabase: {e}")
        return self

    def query(self, tabla: str, filtros: dict = None) -> list:
        if not self.cliente:
            return []
        q = self.cliente.table(tabla).select("*")
        if filtros:
            for col, val in filtros.items():
                q = q.eq(col, val)
        return q.execute().data or []

    def insertar(self, tabla: str, datos: dict) -> dict:
        if not self.cliente:
            return {}
        res = self.cliente.table(tabla).insert(datos).execute()
        return res.data[0] if res.data else {}

    def actualizar(self, tabla: str, datos: dict, filtros: dict) -> dict:
        if not self.cliente:
            return {}
        q = self.cliente.table(tabla).update(datos)
        for col, val in filtros.items():
            q = q.eq(col, val)
        res = q.execute()
        return res.data[0] if res.data else {}


# ─────────────────────────────────────────────────────
# CLASE PRINCIPAL - FunerariaDB
# ─────────────────────────────────────────────────────
class FunerariaDB:
    """
    Punto de entrada principal.
    Usa SQLite en local y sincroniza con Supabase cuando hay internet.
    """

    def __init__(self):
        self.local = DBLocal()
        self.nube  = DBNube()
        self.modo  = "local"

    def iniciar(self):
        """Inicializa la BD local y conecta a la nube si hay internet."""
        self.local.conectar().ejecutar_schema()

        if hay_internet():
            self.nube.conectar()
            self.modo = "dual"
            print("🌐 Modo: LOCAL + NUBE (sincronización activa)")
        else:
            print("💾 Modo: SOLO LOCAL (sin internet)")
        return self

    # ── USUARIOS ──────────────────────────────────────

    def crear_usuario(self, nombre: str, apellido: str, email: str,
                      contrasena: str, rol: str = "empleado") -> dict:
        """Registra un nuevo usuario con contraseña hasheada."""
        # Validaciones
        if rol not in ("admin", "empleado", "recepcion"):
            raise ValueError("Rol inválido. Usa: admin, empleado, recepcion")

        hash_pw = Auth.hashear_contrasena(contrasena)
        uid = str(uuid.uuid4())
        ahora = datetime.now().isoformat()

        datos = {
            "id": uid, "nombre": nombre, "apellido": apellido,
            "email": email, "contrasena": hash_pw,
            "rol": rol, "creado_en": ahora
        }

        # Guardar local
        self.local.ejecutar(
            """INSERT INTO usuarios (id,nombre,apellido,email,contrasena,rol,creado_en)
               VALUES (?,?,?,?,?,?,?)""",
            (uid, nombre, apellido, email, hash_pw, rol, ahora)
        )

        # Guardar en nube si hay conexión
        if self.modo == "dual":
            try:
                self.nube.insertar("usuarios", datos)
            except Exception as e:
                print(f"  ⚠ No se pudo sincronizar usuario a la nube: {e}")

        print(f"✓ Usuario creado: {nombre} {apellido} ({email}) — rol: {rol}")
        return {"id": uid, "email": email, "rol": rol}

    def login(self, email: str, contrasena: str, ip: str = "") -> dict:
        """
        Autentica un usuario. Retorna token JWT si las credenciales son correctas.

        Returns:
            {"token": str, "usuario": dict, "expira": str}
        """
        filas = self.local.query(
            "SELECT * FROM usuarios WHERE email=? AND activo=1", (email,)
        )

        if not filas:
            raise ValueError("Email o contraseña incorrectos")

        usuario = filas[0]

        if not Auth.verificar_contrasena(contrasena, usuario["contrasena"]):
            raise ValueError("Email o contraseña incorrectos")

        # Generar token
        token = Auth.generar_token(usuario["id"], usuario["email"], usuario["rol"])
        expira = (datetime.utcnow() + timedelta(hours=Config.JWT_EXPIRA_HORAS)).isoformat()

        # Registrar sesión en local
        sid = str(uuid.uuid4())
        self.local.ejecutar(
            "INSERT INTO sesiones (id,usuario_id,token,expira_en,ip_origen) VALUES (?,?,?,?,?)",
            (sid, usuario["id"], token, expira, ip)
        )

        # Actualizar último acceso
        self.local.ejecutar(
            "UPDATE usuarios SET ultimo_acceso=? WHERE id=?",
            (datetime.now().isoformat(), usuario["id"])
        )

        print(f"✓ Login exitoso: {usuario['nombre']} ({usuario['rol']})")
        return {
            "token":   token,
            "expira":  expira,
            "usuario": {
                "id":       usuario["id"],
                "nombre":   usuario["nombre"],
                "apellido": usuario["apellido"],
                "email":    usuario["email"],
                "rol":      usuario["rol"]
            }
        }

    def verificar_sesion(self, token: str) -> dict:
        """Verifica token JWT activo. Retorna datos del usuario."""
        payload = Auth.verificar_token(token)

        # Verificar que la sesión existe y no fue revocada
        sesiones = self.local.query(
            "SELECT * FROM sesiones WHERE token=? AND expira_en > ?",
            (token, datetime.utcnow().isoformat())
        )
        if not sesiones:
            raise ValueError("Sesión no encontrada o expirada")

        return payload

    def logout(self, token: str):
        """Invalida el token (elimina la sesión)."""
        self.local.ejecutar("DELETE FROM sesiones WHERE token=?", (token,))
        print("✓ Sesión cerrada")

    def cambiar_contrasena(self, usuario_id: str, actual: str, nueva: str):
        """Cambia la contraseña verificando la actual."""
        filas = self.local.query("SELECT * FROM usuarios WHERE id=?", (usuario_id,))
        if not filas:
            raise ValueError("Usuario no encontrado")
        if not Auth.verificar_contrasena(actual, filas[0]["contrasena"]):
            raise ValueError("Contraseña actual incorrecta")
        nuevo_hash = Auth.hashear_contrasena(nueva)
        self.local.ejecutar(
            "UPDATE usuarios SET contrasena=? WHERE id=?", (nuevo_hash, usuario_id)
        )
        print("✓ Contraseña actualizada")

    # ── CONTRATOS ─────────────────────────────────────

    def crear_contrato(self, difunto_id: str, cliente_id: str,
                       empleado_id: str, servicios: list, notas: str = "") -> dict:
        """
        Crea un contrato con sus servicios.

        servicios = [{"servicio_id": str, "cantidad": int}, ...]
        """
        cid = str(uuid.uuid4())
        numero = f"FUN-{datetime.now().year}-{cid[:8].upper()}"
        total = 0

        # Calcular total
        lineas = []
        for item in servicios:
            svc = self.local.query(
                "SELECT precio FROM servicios WHERE id=?", (item["servicio_id"],)
            )
            if svc:
                precio_unit = svc[0]["precio"]
                cantidad    = item.get("cantidad", 1)
                subtotal    = precio_unit * cantidad
                total      += subtotal
                lineas.append({
                    "id": str(uuid.uuid4()), "contrato_id": cid,
                    "servicio_id": item["servicio_id"],
                    "cantidad": cantidad, "precio_unit": precio_unit,
                    "subtotal": subtotal
                })

        # Insertar contrato
        self.local.ejecutar(
            """INSERT INTO contratos
               (id,numero,difunto_id,cliente_id,empleado_id,total,notas)
               VALUES (?,?,?,?,?,?,?)""",
            (cid, numero, difunto_id, cliente_id, empleado_id, total, notas)
        )

        # Insertar líneas de detalle
        for linea in lineas:
            self.local.ejecutar(
                """INSERT INTO contrato_servicios
                   (id,contrato_id,servicio_id,cantidad,precio_unit,subtotal)
                   VALUES (?,?,?,?,?,?)""",
                (linea["id"], cid, linea["servicio_id"],
                 linea["cantidad"], linea["precio_unit"], linea["subtotal"])
            )

        print(f"✓ Contrato {numero} creado — Total: ${total:,.0f}")
        return {"id": cid, "numero": numero, "total": total}

    # ── REPORTES ──────────────────────────────────────

    def reporte_contratos(self, estado: str = None) -> list:
        """Lista contratos con info del difunto y empleado."""
        sql = """
            SELECT c.numero, c.estado, c.total, c.fecha_contrato,
                   d.nombre || ' ' || d.apellido AS difunto,
                   u.nombre || ' ' || u.apellido AS empleado
            FROM contratos c
            JOIN difuntos d ON d.id = c.difunto_id
            JOIN usuarios u ON u.id = c.empleado_id
        """
        params = ()
        if estado:
            sql += " WHERE c.estado = ?"
            params = (estado,)
        sql += " ORDER BY c.fecha_contrato DESC"
        return self.local.query(sql, params)

    def sincronizar(self):
        """Fuerza sincronización de datos locales a la nube."""
        if self.modo != "dual":
            print("⚠ Sin conexión a internet. No se puede sincronizar.")
            return

        tablas = ["usuarios","difuntos","clientes","servicios",
                  "contratos","contrato_servicios","pagos"]
        for tabla in tablas:
            filas = self.local.query(f"SELECT * FROM {tabla}")
            for fila in filas:
                try:
                    self.nube.insertar(tabla, fila)
                except Exception:
                    pass  # Ya existe, ignorar conflictos
        print(f"✓ Sincronización completada ({sum(1 for t in tablas)} tablas)")

    def cerrar(self):
        self.local.cerrar()


# ─────────────────────────────────────────────────────
# DEMO RÁPIDA
# ─────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 50)
    print("  SISTEMA DE BASE DE DATOS - FUNERARIA")
    print("=" * 50)

    db = FunerariaDB()
    db.iniciar()

    print("\n--- Creando usuario de prueba ---")
    try:
        usuario = db.crear_usuario(
            nombre="María", apellido="Rodríguez",
            email="maria@funeraria.com",
            contrasena="Clave2024!",
            rol="recepcion"
        )
    except Exception as e:
        print(f"  (Usuario ya existe: {e})")

    print("\n--- Probando login ---")
    try:
        sesion = db.login("admin@funeraria.com", "Admin2024!")
        print(f"  Token generado (primeros 30 chars): {sesion['token'][:30]}...")
        print(f"  Rol: {sesion['usuario']['rol']}")

        print("\n--- Verificando sesión ---")
        payload = db.verificar_sesion(sesion["token"])
        print(f"  Sesión válida para: {payload['email']}")

        print("\n--- Cerrando sesión ---")
        db.logout(sesion["token"])

    except Exception as e:
        print(f"  Error: {e}")

    print("\n--- Servicios disponibles ---")
    servicios = db.local.query("SELECT nombre, precio, categoria FROM servicios ORDER BY precio")
    for s in servicios:
        print(f"  • {s['nombre']:30s} ${s['precio']:>12,.0f}  [{s['categoria']}]")

    db.cerrar()
    print("\n✓ Listo. BD guardada en:", Config.DB_LOCAL_PATH)
