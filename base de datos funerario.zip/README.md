# 🏛️ Base de Datos — Sistema Funerario

Sistema de base de datos con soporte **local (SQLite)** y **nube (Supabase)** para funerarías.
Funciona sin internet y sincroniza automáticamente cuando hay conexión.

---

## 📦 Instalación

```bash
# 1. Instalar dependencias
pip install bcrypt PyJWT python-dotenv supabase requests

# 2. Configurar variables de entorno
cp config/.env.ejemplo .env
# Edita .env con tu editor favorito

# 3. Ejecutar demo
python src/funeraria_db.py
```

---

## 🗄️ Tablas incluidas

| Tabla               | Descripción                          |
|---------------------|--------------------------------------|
| `usuarios`          | Empleados con contraseña hasheada    |
| `sesiones`          | Control de sesiones activas (JWT)    |
| `difuntos`          | Registro de personas fallecidas      |
| `clientes`          | Familiares / responsables            |
| `servicios`         | Catálogo de servicios y precios      |
| `contratos`         | Contratos de servicio funerario      |
| `contrato_servicios`| Detalle de servicios por contrato    |
| `pagos`             | Registro de pagos y métodos          |

---

## 👤 Roles de usuario

| Rol          | Permisos                              |
|--------------|---------------------------------------|
| `admin`      | Acceso total al sistema               |
| `empleado`   | Crear contratos, registrar difuntos   |
| `recepcion`  | Ver y registrar clientes / pagos      |

---

## 🔐 Seguridad

- **Contraseñas**: Hasheadas con **bcrypt** (factor 12). Nunca se almacena texto plano.
- **Sesiones**: Tokens **JWT** firmados con expiración configurable.
- **Nube**: Supabase con **Row Level Security (RLS)** activado.
- **Local**: SQLite con **foreign keys** y **WAL mode**.

---

## 💻 Uso básico en Python

```python
from src.funeraria_db import FunerariaDB

db = FunerariaDB()
db.iniciar()   # Detecta automáticamente local o dual

# Crear usuario
db.crear_usuario(
    nombre="Carlos", apellido="López",
    email="carlos@funeraria.com",
    contrasena="MiClave123!",
    rol="empleado"
)

# Login
sesion = db.login("carlos@funeraria.com", "MiClave123!")
token = sesion["token"]   # JWT para usar en requests

# Verificar sesión activa
usuario = db.verificar_sesion(token)

# Cerrar sesión
db.logout(token)

# Cambiar contraseña
db.cambiar_contrasena(usuario["sub"], "MiClave123!", "NuevaClave456!")
```

---

## ☁️ Configurar Supabase (nube)

1. Crea cuenta gratis en [supabase.com](https://supabase.com)
2. Crea un nuevo proyecto
3. Ve a **SQL Editor** y ejecuta el archivo `migrations/002_schema_supabase.sql`
4. Ve a **Settings → API** y copia tu URL y clave
5. Pégalos en tu archivo `.env`

---

## 🔄 Sincronización local ↔ nube

El sistema detecta internet automáticamente:

- **Con internet**: guarda local Y en Supabase simultáneamente
- **Sin internet**: guarda solo en SQLite local
- **Al reconectarse**: llama `db.sincronizar()` para enviar cambios pendientes

```python
db.sincronizar()   # Sube todos los registros locales a Supabase
```

---

## 📁 Estructura del proyecto

```
funeraria-db/
├── src/
│   └── funeraria_db.py         # Código principal
├── migrations/
│   ├── 001_schema.sql          # Schema SQLite (local)
│   └── 002_schema_supabase.sql # Schema PostgreSQL (Supabase)
├── config/
│   └── .env.ejemplo            # Plantilla de configuración
└── README.md
```

---

## 👤 Usuario administrador inicial

```
Email:      admin@funeraria.com
Contraseña: Admin2024!
```
> ⚠️ **Cambia la contraseña inmediatamente** en producción.

---

## 📋 Servicios precargados

| Servicio              | Precio (COP)  | Categoría   |
|-----------------------|---------------|-------------|
| Servicio básico       | $1,500,000    | básico      |
| Servicio intermedio   | $2,800,000    | intermedio  |
| Servicio premium      | $5,000,000    | premium     |
| Cremación             | $1,200,000    | adicional   |
| Arreglo floral        | $250,000      | adicional   |
| Esquela en periódico  | $150,000      | adicional   |
| Traslado aéreo        | $3,500,000    | adicional   |
| Sala VIP              | $800,000      | adicional   |
