-- ============================================================
--  BASE DE DATOS - FUNERARIA
--  Compatible con SQLite (local) y PostgreSQL (Supabase/nube)
-- ============================================================

-- ────────────────────────────────────────
-- TABLA: usuarios
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),  -- UUID v4 compatible
    nombre      TEXT NOT NULL,
    apellido    TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    contrasena  TEXT NOT NULL,          -- Hash bcrypt almacenado aquí NUNCA texto plano
    rol         TEXT NOT NULL DEFAULT 'empleado'
                    CHECK(rol IN ('admin','empleado','recepcion')),
    activo      INTEGER NOT NULL DEFAULT 1,  -- 1=activo, 0=inactivo
    creado_en   TEXT NOT NULL DEFAULT (datetime('now')),
    ultimo_acceso TEXT
);

-- ────────────────────────────────────────
-- TABLA: difuntos
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS difuntos (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre          TEXT NOT NULL,
    apellido        TEXT NOT NULL,
    fecha_nacimiento TEXT,
    fecha_defuncion TEXT NOT NULL,
    causa_defuncion TEXT,
    documento_id    TEXT,              -- Cédula o pasaporte
    registrado_por  TEXT NOT NULL,     -- FK usuarios.id
    creado_en       TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (registrado_por) REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- TABLA: clientes (familiares del difunto)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clientes (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre      TEXT NOT NULL,
    apellido    TEXT NOT NULL,
    telefono    TEXT,
    email       TEXT,
    direccion   TEXT,
    relacion    TEXT,                  -- parentesco con el difunto
    creado_en   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ────────────────────────────────────────
-- TABLA: servicios (catálogo)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS servicios (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre      TEXT NOT NULL,
    descripcion TEXT,
    precio      REAL NOT NULL DEFAULT 0,
    categoria   TEXT NOT NULL DEFAULT 'general'
                    CHECK(categoria IN ('basico','intermedio','premium','adicional')),
    activo      INTEGER NOT NULL DEFAULT 1,
    creado_en   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ────────────────────────────────────────
-- TABLA: contratos
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contratos (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    numero          TEXT NOT NULL UNIQUE,   -- Número legible: FUN-2024-001
    difunto_id      TEXT NOT NULL,
    cliente_id      TEXT NOT NULL,
    empleado_id     TEXT NOT NULL,
    fecha_contrato  TEXT NOT NULL DEFAULT (datetime('now')),
    fecha_servicio  TEXT,
    estado          TEXT NOT NULL DEFAULT 'pendiente'
                        CHECK(estado IN ('pendiente','en_proceso','completado','cancelado')),
    total           REAL NOT NULL DEFAULT 0,
    notas           TEXT,
    FOREIGN KEY (difunto_id)  REFERENCES difuntos(id),
    FOREIGN KEY (cliente_id)  REFERENCES clientes(id),
    FOREIGN KEY (empleado_id) REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- TABLA: contrato_servicios (detalle)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contrato_servicios (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    contrato_id TEXT NOT NULL,
    servicio_id TEXT NOT NULL,
    cantidad    INTEGER NOT NULL DEFAULT 1,
    precio_unit REAL NOT NULL,
    subtotal    REAL NOT NULL,
    FOREIGN KEY (contrato_id) REFERENCES contratos(id),
    FOREIGN KEY (servicio_id) REFERENCES servicios(id)
);

-- ────────────────────────────────────────
-- TABLA: pagos
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pagos (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    contrato_id     TEXT NOT NULL,
    monto           REAL NOT NULL,
    metodo_pago     TEXT NOT NULL DEFAULT 'efectivo'
                        CHECK(metodo_pago IN ('efectivo','tarjeta','transferencia','cheque')),
    fecha_pago      TEXT NOT NULL DEFAULT (datetime('now')),
    registrado_por  TEXT NOT NULL,
    comprobante     TEXT,
    FOREIGN KEY (contrato_id)    REFERENCES contratos(id),
    FOREIGN KEY (registrado_por) REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- TABLA: sesiones (control de acceso)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sesiones (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    usuario_id  TEXT NOT NULL,
    token       TEXT NOT NULL UNIQUE,
    expira_en   TEXT NOT NULL,
    ip_origen   TEXT,
    creado_en   TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- ÍNDICES para mejor rendimiento
-- ────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_usuarios_email      ON usuarios(email);
CREATE INDEX IF NOT EXISTS idx_contratos_estado    ON contratos(estado);
CREATE INDEX IF NOT EXISTS idx_contratos_difunto   ON contratos(difunto_id);
CREATE INDEX IF NOT EXISTS idx_pagos_contrato      ON pagos(contrato_id);
CREATE INDEX IF NOT EXISTS idx_sesiones_token      ON sesiones(token);
CREATE INDEX IF NOT EXISTS idx_sesiones_usuario    ON sesiones(usuario_id);

-- ────────────────────────────────────────
-- DATOS INICIALES - Servicios de catálogo
-- ────────────────────────────────────────
INSERT OR IGNORE INTO servicios (id, nombre, descripcion, precio, categoria) VALUES
    ('svc-001', 'Servicio básico',        'Ataúd sencillo, velación 4h, traslado local',      1500000, 'basico'),
    ('svc-002', 'Servicio intermedio',    'Ataúd estándar, velación 8h, traslado 50km',       2800000, 'intermedio'),
    ('svc-003', 'Servicio premium',       'Ataúd premium, velación 24h, traslado ilimitado',  5000000, 'premium'),
    ('svc-004', 'Cremación',              'Servicio completo de cremación con urna',           1200000, 'adicional'),
    ('svc-005', 'Arreglo floral',         'Corona de flores naturales',                         250000, 'adicional'),
    ('svc-006', 'Esquela en periódico',   'Publicación en diario local',                        150000, 'adicional'),
    ('svc-007', 'Traslado aéreo',         'Traslado en avión nacional',                        3500000, 'adicional'),
    ('svc-008', 'Sala VIP',              'Sala privada con comodidades especiales',             800000, 'adicional');

-- ────────────────────────────────────────
-- USUARIO ADMINISTRADOR INICIAL
-- Contraseña: Admin2024! (hash bcrypt, cámbiala al iniciar)
-- ────────────────────────────────────────
INSERT OR IGNORE INTO usuarios (id, nombre, apellido, email, contrasena, rol) VALUES
    ('usr-admin-001',
     'Administrador',
     'Sistema',
     'admin@funeraria.com',
     '$2b$12$KIX/p.yAu3vf5uQgYlSWEuz.eXP5Bw1Xx1BRx5wEdj5VZbJkCyMGm',
     'admin');
