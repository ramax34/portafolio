
const express = require('express');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'data.json');

function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    const seed = {
      users: [
        { id: 1, name: "Ana", email: "ana@fit.local", password: "ana123", goal: "Fuerza" },
        { id: 2, name: "Carlos", email: "carlos@fit.local", password: "carlos123", goal: "Resistencia" }
      ],
      workouts: [
        { id: 1, userId: 1, type: "Fuerza", activity: "Sentadillas", durationMin: 30, sets: 4, reps: 10, intensity: "media", date: "2025-11-27" },
        { id: 2, userId: 1, type: "Cardio", activity: "Correr", durationMin: 20, sets: null, reps: null, intensity: "alta", date: "2025-11-28" },
        { id: 3, userId: 2, type: "Cardio", activity: "Bicicleta", durationMin: 40, sets: null, reps: null, intensity: "media", date: "2025-11-27" }
      ],
      meals: [
        { id: 1, userId: 1, mealType: "Desayuno", category: "Proteínas", energyLevel: "normal", notes: "Huevos revueltos + pan", date: "2025-11-27" },
        { id: 2, userId: 1, mealType: "Almuerzo", category: "Balanceado", energyLevel: "normal", notes: "Pollo + arroz + ensalada", date: "2025-11-27" },
        { id: 3, userId: 1, mealType: "Cena", category: "Ligero", energyLevel: "ligero", notes: "Yogur + fruta", date: "2025-11-27" }
      ]
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(seed, null, 2), 'utf8');
    return seed;
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf8');
  return JSON.parse(raw);
}

function saveData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

let db = loadData();

function getNextId(list) {
  if (!list.length) return 1;
  return Math.max(...list.map(i => i.id)) + 1;
}

// -------- AUTH SIMPLE (demo, sin hashes) --------
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.users.find(u => u.email === email && u.password === password);
  if (!user) return res.status(401).json({ error: "Credenciales inválidas" });
  const token = "demo-" + user.id + "-" + Date.now();
  res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      goal: user.goal
    }
  });
});

// -------- WORKOUTS --------
app.get('/api/workouts', (req, res) => {
  const userId = Number(req.query.userId);
  if (!userId) return res.status(400).json({ error: "userId requerido" });
  const workouts = db.workouts
    .filter(w => w.userId === userId)
    .sort((a, b) => a.date.localeCompare(b.date));
  res.json(workouts);
});

app.post('/api/workouts', (req, res) => {
  const { userId, type, activity, durationMin, sets, reps, intensity, date } = req.body;
  if (!userId || !type || !activity || !date) {
    return res.status(400).json({ error: "userId, type, activity y date son obligatorios" });
  }
  const w = {
    id: getNextId(db.workouts),
    userId: Number(userId),
    type,
    activity,
    durationMin: durationMin ? Number(durationMin) : null,
    sets: sets ? Number(sets) : null,
    reps: reps ? Number(reps) : null,
    intensity: intensity || null,
    date
  };
  db.workouts.push(w);
  saveData(db);
  res.status(201).json(w);
});

// -------- MEALS --------
app.get('/api/meals', (req, res) => {
  const userId = Number(req.query.userId);
  if (!userId) return res.status(400).json({ error: "userId requerido" });
  const meals = db.meals
    .filter(m => m.userId === userId)
    .sort((a, b) => a.date.localeCompare(b.date));
  res.json(meals);
});

app.post('/api/meals', (req, res) => {
  const { userId, mealType, category, energyLevel, notes, date } = req.body;
  if (!userId || !mealType || !date) {
    return res.status(400).json({ error: "userId, mealType y date son obligatorios" });
  }
  const m = {
    id: getNextId(db.meals),
    userId: Number(userId),
    mealType,
    category: category || null,
    energyLevel: energyLevel || null,
    notes: notes || "",
    date
  };
  db.meals.push(m);
  saveData(db);
  res.status(201).json(m);
});

// -------- STATS --------
app.get('/api/stats/overview', (req, res) => {
  const userId = Number(req.query.userId);
  if (!userId) return res.status(400).json({ error: "userId requerido" });

  const workouts = db.workouts.filter(w => w.userId === userId);
  const meals = db.meals.filter(m => m.userId === userId);

  const totalWorkouts = workouts.length;
  const totalMinutes = workouts.reduce((sum, w) => sum + (w.durationMin || 0), 0);

  const byType = {};
  workouts.forEach(w => {
    byType[w.type] = (byType[w.type] || 0) + 1;
  });

  const byEnergy = {};
  meals.forEach(m => {
    if (!m.energyLevel) return;
    byEnergy[m.energyLevel] = (byEnergy[m.energyLevel] || 0) + 1;
  });

  const byDate = {};
  workouts.forEach(w => {
    byDate[w.date] = (byDate[w.date] || 0) + (w.durationMin || 0);
  });

  res.json({
    totalWorkouts,
    totalMinutes,
    workoutsByType: byType,
    mealsByEnergy: byEnergy,
    minutesByDate: byDate
  });
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Fitness App Live escuchando en http://localhost:${PORT}`);
});
