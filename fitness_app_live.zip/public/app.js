
const API_BASE = "";
let currentUser = null;

function formToJSON(form) {
  const data = new FormData(form);
  return Object.fromEntries(data.entries());
}

// LOGIN
const loginScreen = document.getElementById("login-screen");
const appRoot = document.getElementById("app-root");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.style.display = "none";
  const payload = formToJSON(loginForm);
  try {
    const res = await fetch(API_BASE + "/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      loginError.style.display = "block";
      return;
    }
    const data = await res.json();
    currentUser = data.user;
    localStorage.setItem("fitnessUser", JSON.stringify(currentUser));
    enterApp();
  } catch {
    loginError.style.display = "block";
  }
});

document.getElementById("logout-btn").addEventListener("click", () => {
  localStorage.removeItem("fitnessUser");
  currentUser = null;
  location.reload();
});

function enterApp() {
  loginScreen.style.display = "none";
  appRoot.style.display = "flex";
  document.getElementById("user-name").textContent = currentUser.name;
  document.getElementById("user-goal").textContent = "Objetivo: " + (currentUser.goal || "Sin definir");
  initApp();
}

const stored = localStorage.getItem("fitnessUser");
if (stored) {
  currentUser = JSON.parse(stored);
  enterApp();
}

// NAV INFERIOR
const navButtons = document.querySelectorAll(".nav-btn");
const viewDashboard = document.getElementById("view-dashboard");
const panelWorkouts = document.getElementById("view-workouts");
const panelMeals = document.getElementById("view-meals");

navButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const view = btn.dataset.view;
    navButtons.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");

    if (view === "dashboard") {
      viewDashboard.style.display = "block";
      panelWorkouts.style.display = "none";
      panelMeals.style.display = "none";
    } else if (view === "workouts") {
      viewDashboard.style.display = "none";
      panelWorkouts.style.display = "flex";
      panelMeals.style.display = "none";
    } else if (view === "meals") {
      viewDashboard.style.display = "none";
      panelWorkouts.style.display = "none";
      panelMeals.style.display = "flex";
    }
  });
});

// BACK BUTTONS
document.querySelectorAll(".back-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    panelWorkouts.style.display = "none";
    panelMeals.style.display = "none";
    viewDashboard.style.display = "block";
    navButtons.forEach((b) => {
      b.classList.toggle("active", b.dataset.view === "dashboard");
    });
  });
});

// CHARTS
let chartMinutes = null;
let chartWorkoutTypes = null;
let chartMeals = null;

async function loadOverviewStats() {
  const res = await fetch(API_BASE + `/api/stats/overview?userId=${currentUser.id}`);
  const data = await res.json();

  document.getElementById("kpi-total-workouts").textContent = data.totalWorkouts;
  document.getElementById("kpi-total-minutes").textContent = data.totalMinutes;

  // minutos por día
  const dates = Object.keys(data.minutesByDate).sort();
  const minutes = dates.map((d) => data.minutesByDate[d]);

  const ctxMinutes = document.getElementById("chart-minutes").getContext("2d");
  if (chartMinutes) chartMinutes.destroy();
  chartMinutes = new Chart(ctxMinutes, {
    type: "line",
    data: {
      labels: dates,
      datasets: [
        {
          label: "Minutos",
          data: minutes,
          tension: 0.35,
          borderWidth: 2,
          pointRadius: 3,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false }, ticks: { color: "#9ca3af" } },
        y: { grid: { color: "rgba(55,65,81,0.5)" }, ticks: { color: "#9ca3af" } },
      },
      plugins: { legend: { labels: { color: "#e5e7eb" } } },
    },
  });

  // tipos de entreno
  const typeLabels = Object.keys(data.workoutsByType);
  const typeValues = Object.values(data.workoutsByType);
  const ctxTypes = document.getElementById("chart-workout-types").getContext("2d");
  if (chartWorkoutTypes) chartWorkoutTypes.destroy();
  chartWorkoutTypes = new Chart(ctxTypes, {
    type: "bar",
    data: {
      labels: typeLabels,
      datasets: [{ label: "Sesiones", data: typeValues }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { grid: { display: false }, ticks: { color: "#9ca3af" } },
        y: { grid: { color: "rgba(55,65,81,0.5)" }, ticks: { color: "#9ca3af" } },
      },
      plugins: { legend: { labels: { color: "#e5e7eb" } } },
    },
  });

  // comidas por energía
  const energyLabels = Object.keys(data.mealsByEnergy);
  const energyValues = Object.values(data.mealsByEnergy);
  const ctxMeals = document.getElementById("chart-meals").getContext("2d");
  if (chartMeals) chartMeals.destroy();
  chartMeals = new Chart(ctxMeals, {
    type: "pie",
    data: {
      labels: energyLabels,
      datasets: [{ data: energyValues }],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { labels: { color: "#e5e7eb" } } },
    },
  });
}

// WORKOUTS
async function loadWorkouts() {
  const res = await fetch(API_BASE + `/api/workouts?userId=${currentUser.id}`);
  const workouts = await res.json();
  const list = document.getElementById("workouts-list");
  list.innerHTML = "";
  workouts.slice().reverse().forEach((w) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${w.activity}</div>
          <div class="list-item-meta">${w.type} · ${w.intensity || "intensidad libre"}</div>
        </div>
        <span class="list-item-meta">${w.date}</span>
      </div>
      <div class="list-item-meta">
        ${w.durationMin ? w.durationMin + " min · " : ""}${w.sets ? w.sets + "x" + (w.reps || "") + " reps" : ""}
      </div>
    `;
    list.appendChild(item);
  });
}

function setupWorkoutForm() {
  const form = document.getElementById("form-workout");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    payload.userId = currentUser.id;
    const res = await fetch(API_BASE + "/api/workouts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("No se pudo guardar el entreno. Revisa los campos.");
      return;
    }
    form.reset();
    await Promise.all([loadWorkouts(), loadOverviewStats()]);
  });
}

// MEALS
async function loadMeals() {
  const res = await fetch(API_BASE + `/api/meals?userId=${currentUser.id}`);
  const meals = await res.json();
  const list = document.getElementById("meals-list");
  list.innerHTML = "";
  meals.slice().reverse().forEach((m) => {
    const item = document.createElement("div");
    item.className = "list-item";
    item.innerHTML = `
      <div class="list-item-header">
        <div>
          <div class="list-item-title">${m.mealType}</div>
          <div class="list-item-meta">${m.category || "Sin categoría"} · ${m.energyLevel || "energía libre"}</div>
        </div>
        <span class="list-item-meta">${m.date}</span>
      </div>
      <div class="list-item-meta">${m.notes || ""}</div>
    `;
    list.appendChild(item);
  });
}

function setupMealForm() {
  const form = document.getElementById("form-meal");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = formToJSON(form);
    payload.userId = currentUser.id;
    const res = await fetch(API_BASE + "/api/meals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      alert("No se pudo guardar la comida. Revisa los campos.");
      return;
    }
    form.reset();
    await Promise.all([loadMeals(), loadOverviewStats()]);
  });
}

// INIT
async function initApp() {
  await Promise.all([loadOverviewStats(), loadWorkouts(), loadMeals()]);
  setupWorkoutForm();
  setupMealForm();
}
