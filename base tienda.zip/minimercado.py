"""
minimercado.py
──────────────
Sistema de base de datos para tienda / minimercado de comida.
Funciona OFFLINE (SQLite local) y se sincroniza con Supabase cuando hay internet.

Instalación rápida:
    pip install bcrypt PyJWT python-dotenv supabase requests

Uso básico:
    from minimercado import Minimercado
    db = Minimercado().iniciar()

    sesion = db.login("admin@minimercado.com", "Admin2024!")
    db.registrar_venta(sesion["usuario"]["id"], items=[
        {"producto_id": "prd-001", "cantidad": 2},
        {"producto_id": "prd-004", "cantidad": 1},
    ], metodo_pago="efectivo")
"""

import sqlite3
import bcrypt
import jwt
import uuid
import os
import socket
from datetime import datetime, timedelta, timezone
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ─────────────────────────────────────────────────────
# CONFIGURACIÓN
# ─────────────────────────────────────────────────────
class Config:
    DB_PATH          = os.getenv("DB_PATH", "minimercado.db")
    SUPABASE_URL     = os.getenv("SUPABASE_URL", "")
    SUPABASE_KEY     = os.getenv("SUPABASE_KEY", "")
    JWT_SECRET       = os.getenv("JWT_SECRET", "cambia-esta-clave-en-produccion!")
    JWT_HORAS        = int(os.getenv("JWT_HORAS", "10"))
    BCRYPT_ROUNDS    = int(os.getenv("BCRYPT_ROUNDS", "12"))
    IVA_DEFAULT      = float(os.getenv("IVA_DEFAULT", "19"))


# ─────────────────────────────────────────────────────
# UTILIDADES
# ─────────────────────────────────────────────────────
def hay_internet(timeout=2):
    try:
        socket.setdefaulttimeout(timeout)
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect(("8.8.8.8", 53))
        return True
    except socket.error:
        return False

def ahora():
    return datetime.now().isoformat()

def uid():
    return str(uuid.uuid4())

def numero_secuencial(prefijo: str, conexion) -> str:
    tabla = "ventas" if prefijo == "VTA" else "compras"
    col   = "numero"
    año   = datetime.now().year
    cur   = conexion.execute(
        f"SELECT COUNT(*) FROM {tabla} WHERE numero LIKE '{prefijo}-{año}-%'"
    )
    n = cur.fetchone()[0] + 1
    return f"{prefijo}-{año}-{n:05d}"


# ─────────────────────────────────────────────────────
# AUTENTICACIÓN
# ─────────────────────────────────────────────────────
class Auth:
    @staticmethod
    def hashear(pw: str) -> str:
        if len(pw) < 6:
            raise ValueError("La contraseña debe tener al menos 6 caracteres")
        return bcrypt.hashpw(pw.encode(), bcrypt.gensalt(Config.BCRYPT_ROUNDS)).decode()

    @staticmethod
    def verificar(pw: str, hsh: str) -> bool:
        return bcrypt.checkpw(pw.encode(), hsh.encode())

    @staticmethod
    def token(usuario_id: str, email: str, rol: str) -> str:
        now = datetime.now(timezone.utc)
        payload = {
            "sub":   usuario_id,
            "email": email,
            "rol":   rol,
            "iat":   now,
            "exp":   now + timedelta(hours=Config.JWT_HORAS),
        }
        return jwt.encode(payload, Config.JWT_SECRET, algorithm="HS256")

    @staticmethod
    def decodificar(token: str) -> dict:
        try:
            return jwt.decode(token, Config.JWT_SECRET, algorithms=["HS256"])
        except jwt.ExpiredSignatureError:
            raise ValueError("Sesión expirada. Inicia sesión nuevamente.")
        except jwt.InvalidTokenError:
            raise ValueError("Token inválido.")


# ─────────────────────────────────────────────────────
# BASE DE DATOS LOCAL
# ─────────────────────────────────────────────────────
class DB:
    def __init__(self):
        self.con = None

    def conectar(self):
        self.con = sqlite3.connect(Config.DB_PATH, check_same_thread=False)
        self.con.row_factory = sqlite3.Row
        self.con.execute("PRAGMA foreign_keys = ON")
        self.con.execute("PRAGMA journal_mode  = WAL")
        return self

    def _schema_embebido(self):
        """Schema embebido para cuando no existe el archivo SQL."""
        self.con.executescript("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
            contrasena TEXT NOT NULL, rol TEXT NOT NULL DEFAULT 'cajero',
            activo INTEGER NOT NULL DEFAULT 1,
            creado_en TEXT NOT NULL DEFAULT (datetime('now')), ultimo_acceso TEXT
        );
        CREATE TABLE IF NOT EXISTS categorias (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL UNIQUE,
            descripcion TEXT, icono TEXT, activa INTEGER NOT NULL DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS proveedores (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, contacto TEXT,
            telefono TEXT, email TEXT, direccion TEXT,
            activo INTEGER NOT NULL DEFAULT 1, creado_en TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS productos (
            id TEXT PRIMARY KEY, codigo_barras TEXT UNIQUE, nombre TEXT NOT NULL,
            descripcion TEXT, categoria_id TEXT NOT NULL, proveedor_id TEXT,
            unidad_medida TEXT NOT NULL DEFAULT 'unidad',
            precio_compra REAL NOT NULL DEFAULT 0, precio_venta REAL NOT NULL DEFAULT 0,
            iva_porcentaje REAL NOT NULL DEFAULT 0,
            stock_actual REAL NOT NULL DEFAULT 0, stock_minimo REAL NOT NULL DEFAULT 5,
            stock_maximo REAL NOT NULL DEFAULT 100,
            activo INTEGER NOT NULL DEFAULT 1, creado_en TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        );
        CREATE TABLE IF NOT EXISTS clientes (
            id TEXT PRIMARY KEY, nombre TEXT NOT NULL, documento TEXT UNIQUE,
            telefono TEXT, email TEXT, saldo_puntos REAL NOT NULL DEFAULT 0,
            creado_en TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS ventas (
            id TEXT PRIMARY KEY, numero TEXT NOT NULL UNIQUE,
            usuario_id TEXT NOT NULL, cliente_id TEXT,
            subtotal REAL NOT NULL DEFAULT 0, descuento REAL NOT NULL DEFAULT 0,
            iva REAL NOT NULL DEFAULT 0, total REAL NOT NULL DEFAULT 0,
            metodo_pago TEXT NOT NULL DEFAULT 'efectivo',
            estado TEXT NOT NULL DEFAULT 'completada',
            notas TEXT, fecha TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS venta_items (
            id TEXT PRIMARY KEY, venta_id TEXT NOT NULL, producto_id TEXT NOT NULL,
            cantidad REAL NOT NULL DEFAULT 1, precio_unit REAL NOT NULL,
            descuento REAL NOT NULL DEFAULT 0, iva_porc REAL NOT NULL DEFAULT 0,
            subtotal REAL NOT NULL,
            FOREIGN KEY (venta_id)    REFERENCES ventas(id),
            FOREIGN KEY (producto_id) REFERENCES productos(id)
        );
        CREATE TABLE IF NOT EXISTS compras (
            id TEXT PRIMARY KEY, numero TEXT NOT NULL UNIQUE,
            proveedor_id TEXT NOT NULL, usuario_id TEXT NOT NULL,
            total REAL NOT NULL DEFAULT 0, estado TEXT NOT NULL DEFAULT 'recibida',
            factura_ref TEXT, notas TEXT, fecha TEXT DEFAULT (datetime('now')),
            FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
            FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS compra_items (
            id TEXT PRIMARY KEY, compra_id TEXT NOT NULL, producto_id TEXT NOT NULL,
            cantidad REAL NOT NULL DEFAULT 1, precio_unit REAL NOT NULL,
            subtotal REAL NOT NULL, fecha_vence TEXT,
            FOREIGN KEY (compra_id)   REFERENCES compras(id),
            FOREIGN KEY (producto_id) REFERENCES productos(id)
        );
        CREATE TABLE IF NOT EXISTS movimientos_caja (
            id TEXT PRIMARY KEY, usuario_id TEXT NOT NULL,
            tipo TEXT NOT NULL, monto REAL NOT NULL,
            saldo_antes REAL NOT NULL DEFAULT 0, saldo_des REAL NOT NULL DEFAULT 0,
            concepto TEXT NOT NULL, referencia TEXT,
            fecha TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );
        CREATE TABLE IF NOT EXISTS devoluciones (
            id TEXT PRIMARY KEY, venta_id TEXT NOT NULL, usuario_id TEXT NOT NULL,
            motivo TEXT NOT NULL, total REAL NOT NULL DEFAULT 0,
            fecha TEXT NOT NULL DEFAULT (datetime('now')),
            FOREIGN KEY (venta_id)   REFERENCES ventas(id),
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        );
        CREATE INDEX IF NOT EXISTS idx_prod_barcode ON productos(codigo_barras);
        CREATE INDEX IF NOT EXISTS idx_prod_stock   ON productos(stock_actual);
        CREATE INDEX IF NOT EXISTS idx_ventas_fecha ON ventas(fecha);
        """)

    def _datos_iniciales(self):
        self.con.executescript("""
        INSERT OR IGNORE INTO categorias (id,nombre,descripcion) VALUES
            ('cat-01','Lácteos y huevos',   'Leche, queso, yogur, huevos'),
            ('cat-02','Carnes y embutidos', 'Res, cerdo, pollo, embutidos'),
            ('cat-03','Frutas y verduras',  'Frescas y de temporada'),
            ('cat-04','Panadería',          'Pan, ponqués, galletas'),
            ('cat-05','Granos y harinas',   'Arroz, frijol, azúcar, harina'),
            ('cat-06','Enlatados',          'Atún, sardina, maíz'),
            ('cat-07','Bebidas',            'Gaseosas, jugos, agua, cerveza'),
            ('cat-08','Aseo personal',      'Jabón, crema, shampoo'),
            ('cat-09','Aseo del hogar',     'Detergente, escoba, trapero'),
            ('cat-10','Snacks y dulces',    'Papas, chocolates, café'),
            ('cat-11','Congelados',         'Helados, empanadas'),
            ('cat-12','Bebé y niños',       'Pañales, fórmula');

        INSERT OR IGNORE INTO proveedores (id,nombre,contacto,telefono) VALUES
            ('prv-01','Distribuidora Lácteos del Valle','Carlos Gómez',   '310-111-2233'),
            ('prv-02','Carnes El Campesino',            'Martha Ríos',    '311-222-3344'),
            ('prv-03','Frutas y Verduras La Cosecha',   'Pedro Salcedo',  '312-333-4455'),
            ('prv-04','Distribuidora Nestlé',           'Ana Martínez',   '018009-12345'),
            ('prv-05','Almacenes Éxito Mayorista',      'Luis Herrera',   '313-444-5566');

        INSERT OR IGNORE INTO productos
            (id,codigo_barras,nombre,categoria_id,proveedor_id,unidad_medida,
             precio_compra,precio_venta,iva_porcentaje,stock_actual,stock_minimo) VALUES
            ('prd-001','7702001','Leche entera 1L',       'cat-01','prv-01','unidad',  2800, 3500,  0, 50, 10),
            ('prd-002','7702002','Huevos AAA x12',        'cat-01','prv-01','docena',  4500, 5800,  0, 30,  8),
            ('prd-003','7702003','Queso campesino 500g',  'cat-01','prv-01','unidad',  7000, 9000,  0, 20,  5),
            ('prd-004','7702004','Arroz 1kg',             'cat-05','prv-04','kg',      2200, 2800,  0,100, 20),
            ('prd-005','7702005','Frijol bolo 500g',      'cat-05','prv-05','unidad',  2500, 3200,  0, 60, 10),
            ('prd-006','7702006','Aceite vegetal 1L',     'cat-05','prv-04','unidad',  6800, 8500, 19, 40,  8),
            ('prd-007','7702007','Azúcar 1kg',            'cat-05','prv-04','kg',      2300, 2900,  0, 80, 15),
            ('prd-008','7702008','Atún 170g',             'cat-06','prv-04','unidad',  2800, 3500, 19, 70, 12),
            ('prd-009','7702009','Gaseosa 400ml',         'cat-07','prv-04','unidad',  2000, 2800, 19, 80, 20),
            ('prd-010','7702010','Agua 600ml',            'cat-07','prv-05','unidad',   900, 1500,  0,120, 24),
            ('prd-011','7702011','Pan tajado 480g',       'cat-04','prv-04','unidad',  4200, 5500,  0, 25,  6),
            ('prd-012','7702012','Jabón barra x3',        'cat-08','prv-04','paquete', 5500, 7200,  0, 40, 10),
            ('prd-013','7702013','Papel higiénico x4',   'cat-08','prv-05','paquete', 5000, 6800,  0, 35,  8),
            ('prd-014','7702014','Detergente 500g',       'cat-09','prv-04','unidad',  7500, 9500,  0, 30,  6),
            ('prd-015','7702015','Papas fritas 110g',     'cat-10','prv-04','unidad',  1800, 2500, 19, 60, 15),
            ('prd-016','7702016','Café molido 200g',      'cat-10','prv-04','unidad',  8500,11000,  0, 25,  6),
            ('prd-017','7702017','Salchichas x6',         'cat-02','prv-02','paquete', 5500, 7000,  0, 20,  5),
            ('prd-018','7702018','Yogur 200ml',           'cat-01','prv-01','unidad',  1800, 2500,  0, 30,  8),
            ('prd-019','7702019','Maíz en lata 400g',     'cat-06','prv-05','unidad',  3200, 4200, 19, 25,  6),
            ('prd-020','7702020','Crema dental 75ml',     'cat-08','prv-04','unidad',  3500, 4800,  0, 40, 10);
        """)

    def crear_tablas(self):
        sql_path = Path(__file__).parent.parent / "migrations" / "001_schema.sql"
        if sql_path.exists():
            with open(sql_path, encoding="utf-8") as f:
                self.con.executescript(f.read())
        else:
            self._schema_embebido()
            self._datos_iniciales()
        self.con.commit()
        print("✓ Base de datos lista")
        return self

    def q(self, sql, p=()):
        return [dict(r) for r in self.con.execute(sql, p).fetchall()]

    def uno(self, sql, p=()):
        rows = self.q(sql, p)
        return rows[0] if rows else None

    def exec(self, sql, p=()):
        self.con.execute(sql, p)
        self.con.commit()

    def cerrar(self):
        if self.con:
            self.con.close()


# ─────────────────────────────────────────────────────
# CLASE PRINCIPAL
# ─────────────────────────────────────────────────────
class Minimercado:
    def __init__(self):
        self.db   = DB()
        self.modo = "local"

    def iniciar(self):
        self.db.conectar().crear_tablas()
        self._crear_admin_inicial()

        if hay_internet() and Config.SUPABASE_URL:
            try:
                from supabase import create_client
                self.nube = create_client(Config.SUPABASE_URL, Config.SUPABASE_KEY)
                self.modo = "dual"
                print("🌐 Modo: LOCAL + NUBE")
            except Exception as e:
                print(f"⚠ Supabase no disponible: {e}")
                print("💾 Modo: SOLO LOCAL")
        else:
            print("💾 Modo: SOLO LOCAL (sin internet o Supabase no configurado)")
        return self

    def _crear_admin_inicial(self):
        """Crea el admin con hash bcrypt real si aún usa el placeholder."""
        admin = self.db.uno("SELECT id,contrasena FROM usuarios WHERE email='admin@minimercado.com'")
        if admin and "placeholder" in admin["contrasena"]:
            h = Auth.hashear("Admin2024!")
            self.db.exec("UPDATE usuarios SET contrasena=? WHERE email='admin@minimercado.com'", (h,))
            cajero_h = Auth.hashear("Cajero2024!")
            self.db.exec("UPDATE usuarios SET contrasena=? WHERE email='cajero@minimercado.com'", (cajero_h,))
            print("✓ Contraseñas de usuarios por defecto configuradas")

    # ── AUTENTICACIÓN ─────────────────────────────────

    def login(self, email: str, pw: str) -> dict:
        u = self.db.uno("SELECT * FROM usuarios WHERE email=? AND activo=1", (email,))
        if not u or not Auth.verificar(pw, u["contrasena"]):
            raise ValueError("Email o contraseña incorrectos")
        self.db.exec("UPDATE usuarios SET ultimo_acceso=? WHERE id=?", (ahora(), u["id"]))
        tok = Auth.token(u["id"], u["email"], u["rol"])
        print(f"✓ Login: {u['nombre']} ({u['rol']})")
        return {"token": tok, "usuario": {"id": u["id"], "nombre": u["nombre"],
                                          "email": u["email"], "rol": u["rol"]}}

    def crear_usuario(self, nombre: str, email: str, pw: str,
                      rol: str = "cajero") -> dict:
        if rol not in ("admin", "cajero", "bodeguero"):
            raise ValueError("Rol debe ser: admin, cajero o bodeguero")
        new_id = uid()
        self.db.exec(
            "INSERT INTO usuarios (id,nombre,email,contrasena,rol) VALUES (?,?,?,?,?)",
            (new_id, nombre, email, Auth.hashear(pw), rol)
        )
        print(f"✓ Usuario '{nombre}' creado como {rol}")
        return {"id": new_id, "nombre": nombre, "email": email, "rol": rol}

    # ── PRODUCTOS ─────────────────────────────────────

    def buscar_producto(self, termino: str) -> list:
        """Busca por código de barras o nombre (búsqueda parcial)."""
        return self.db.q(
            """SELECT p.*, c.nombre as categoria
               FROM productos p JOIN categorias c ON c.id=p.categoria_id
               WHERE (p.codigo_barras=? OR p.nombre LIKE ?) AND p.activo=1
               ORDER BY p.nombre LIMIT 20""",
            (termino, f"%{termino}%")
        )

    def crear_producto(self, datos: dict) -> dict:
        """
        datos = {nombre, categoria_id, precio_compra, precio_venta,
                 unidad_medida, stock_actual, stock_minimo,
                 codigo_barras (opc), iva_porcentaje (opc), proveedor_id (opc)}
        """
        nuevo_id = uid()
        self.db.exec(
            """INSERT INTO productos
               (id,codigo_barras,nombre,categoria_id,proveedor_id,unidad_medida,
                precio_compra,precio_venta,iva_porcentaje,stock_actual,stock_minimo)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (nuevo_id,
             datos.get("codigo_barras"),
             datos["nombre"],
             datos["categoria_id"],
             datos.get("proveedor_id"),
             datos.get("unidad_medida", "unidad"),
             datos["precio_compra"],
             datos["precio_venta"],
             datos.get("iva_porcentaje", 0),
             datos.get("stock_actual", 0),
             datos.get("stock_minimo", 5))
        )
        print(f"✓ Producto '{datos['nombre']}' creado")
        return {"id": nuevo_id, **datos}

    def actualizar_precio(self, producto_id: str, precio_venta: float,
                          precio_compra: float = None):
        if precio_compra is not None:
            self.db.exec(
                "UPDATE productos SET precio_venta=?,precio_compra=? WHERE id=?",
                (precio_venta, precio_compra, producto_id)
            )
        else:
            self.db.exec(
                "UPDATE productos SET precio_venta=? WHERE id=?",
                (precio_venta, producto_id)
            )
        print(f"✓ Precio actualizado")

    def stock_bajo(self) -> list:
        """Lista productos con stock menor o igual al mínimo."""
        return self.db.q(
            """SELECT p.nombre, p.stock_actual, p.stock_minimo, c.nombre as categoria
               FROM productos p JOIN categorias c ON c.id=p.categoria_id
               WHERE p.stock_actual <= p.stock_minimo AND p.activo=1
               ORDER BY (p.stock_actual - p.stock_minimo)"""
        )

    # ── VENTAS ────────────────────────────────────────

    def registrar_venta(self, usuario_id: str, items: list,
                        metodo_pago: str = "efectivo",
                        cliente_id: str = None,
                        descuento_global: float = 0,
                        notas: str = "") -> dict:
        """
        Registra una venta completa y descuenta el stock.

        items = [{"producto_id": str, "cantidad": float, "descuento": float}]

        Returns:
            {"id": str, "numero": str, "total": float, "items": list}
        """
        if not items:
            raise ValueError("La venta debe tener al menos un producto")

        venta_id = uid()
        numero   = numero_secuencial("VTA", self.db.con)
        subtotal = 0.0
        iva_total = 0.0
        lineas = []

        for item in items:
            prod = self.db.uno(
                "SELECT * FROM productos WHERE id=? AND activo=1",
                (item["producto_id"],)
            )
            if not prod:
                raise ValueError(f"Producto no encontrado: {item['producto_id']}")

            cant = float(item.get("cantidad", 1))
            if prod["stock_actual"] < cant:
                raise ValueError(
                    f"Stock insuficiente para '{prod['nombre']}'. "
                    f"Disponible: {prod['stock_actual']}, solicitado: {cant}"
                )

            desc_item = float(item.get("descuento", 0))
            precio    = prod["precio_venta"]
            iva_porc  = prod["iva_porcentaje"]
            base      = (precio * cant) - desc_item
            iva_item  = base * (iva_porc / 100)
            sub       = base  # precio ya incluye IVA en Colombia (precio de venta al público)

            subtotal  += sub
            iva_total += iva_item

            lineas.append({
                "id": uid(), "venta_id": venta_id,
                "producto_id": item["producto_id"],
                "cantidad": cant, "precio_unit": precio,
                "descuento": desc_item, "iva_porc": iva_porc,
                "subtotal": sub
            })

        total = subtotal - descuento_global

        # Insertar cabecera de venta
        self.db.exec(
            """INSERT INTO ventas
               (id,numero,usuario_id,cliente_id,subtotal,descuento,iva,total,metodo_pago,notas)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (venta_id, numero, usuario_id, cliente_id,
             subtotal, descuento_global, iva_total, total,
             metodo_pago, notas)
        )

        # Insertar ítems y descontar stock
        for linea in lineas:
            self.db.exec(
                """INSERT INTO venta_items
                   (id,venta_id,producto_id,cantidad,precio_unit,descuento,iva_porc,subtotal)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (linea["id"], linea["venta_id"], linea["producto_id"],
                 linea["cantidad"], linea["precio_unit"],
                 linea["descuento"], linea["iva_porc"], linea["subtotal"])
            )
            self.db.exec(
                "UPDATE productos SET stock_actual=stock_actual-? WHERE id=?",
                (linea["cantidad"], linea["producto_id"])
            )

        # Registrar en caja
        self._mov_caja(usuario_id, "venta", total,
                       f"Venta {numero}", referencia=venta_id)

        print(f"✓ Venta {numero} — Total: ${total:,.0f} ({metodo_pago})")
        return {"id": venta_id, "numero": numero, "total": total,
                "items": len(lineas)}

    def anular_venta(self, venta_id: str, usuario_id: str, motivo: str):
        """Anula una venta y restaura el stock."""
        venta = self.db.uno("SELECT * FROM ventas WHERE id=?", (venta_id,))
        if not venta:
            raise ValueError("Venta no encontrada")
        if venta["estado"] == "anulada":
            raise ValueError("La venta ya está anulada")

        items = self.db.q("SELECT * FROM venta_items WHERE venta_id=?", (venta_id,))

        for item in items:
            self.db.exec(
                "UPDATE productos SET stock_actual=stock_actual+? WHERE id=?",
                (item["cantidad"], item["producto_id"])
            )

        self.db.exec(
            "UPDATE ventas SET estado='anulada', notas=? WHERE id=?",
            (f"ANULADA: {motivo}", venta_id)
        )
        self._mov_caja(usuario_id, "devolucion", -venta["total"],
                       f"Anulación venta {venta['numero']}", referencia=venta_id)
        print(f"✓ Venta {venta['numero']} anulada")

    # ── COMPRAS ───────────────────────────────────────

    def registrar_compra(self, proveedor_id: str, usuario_id: str,
                         items: list, factura_ref: str = "",
                         notas: str = "") -> dict:
        """
        Registra una compra a proveedor y suma al stock.

        items = [{"producto_id": str, "cantidad": float, "precio_unit": float,
                  "fecha_vence": str (opc)}]
        """
        compra_id = uid()
        numero    = numero_secuencial("CMP", self.db.con)
        total     = 0.0
        lineas    = []

        for item in items:
            cant  = float(item["cantidad"])
            precio = float(item["precio_unit"])
            sub   = cant * precio
            total += sub
            lineas.append({
                "id": uid(), "compra_id": compra_id,
                "producto_id": item["producto_id"],
                "cantidad": cant, "precio_unit": precio,
                "subtotal": sub,
                "fecha_vence": item.get("fecha_vence")
            })

        self.db.exec(
            """INSERT INTO compras
               (id,numero,proveedor_id,usuario_id,total,factura_ref,notas)
               VALUES (?,?,?,?,?,?,?)""",
            (compra_id, numero, proveedor_id, usuario_id,
             total, factura_ref, notas)
        )

        for linea in lineas:
            self.db.exec(
                """INSERT INTO compra_items
                   (id,compra_id,producto_id,cantidad,precio_unit,subtotal,fecha_vence)
                   VALUES (?,?,?,?,?,?,?)""",
                (linea["id"], linea["compra_id"], linea["producto_id"],
                 linea["cantidad"], linea["precio_unit"],
                 linea["subtotal"], linea["fecha_vence"])
            )
            # Actualizar stock y precio de compra
            self.db.exec(
                """UPDATE productos SET stock_actual=stock_actual+?,
                   precio_compra=? WHERE id=?""",
                (linea["cantidad"], linea["precio_unit"], linea["producto_id"])
            )

        print(f"✓ Compra {numero} — Total: ${total:,.0f}")
        return {"id": compra_id, "numero": numero, "total": total}

    # ── CAJA ──────────────────────────────────────────

    def _saldo_caja(self) -> float:
        row = self.db.uno(
            "SELECT saldo_des FROM movimientos_caja ORDER BY fecha DESC LIMIT 1"
        )
        return row["saldo_des"] if row else 0.0

    def _mov_caja(self, usuario_id: str, tipo: str, monto: float,
                  concepto: str, referencia: str = None):
        saldo_antes = self._saldo_caja()
        saldo_des   = saldo_antes + monto
        self.db.exec(
            """INSERT INTO movimientos_caja
               (id,usuario_id,tipo,monto,saldo_antes,saldo_des,concepto,referencia)
               VALUES (?,?,?,?,?,?,?,?)""",
            (uid(), usuario_id, tipo, monto, saldo_antes, saldo_des,
             concepto, referencia)
        )

    def apertura_caja(self, usuario_id: str, monto_inicial: float):
        self._mov_caja(usuario_id, "apertura", monto_inicial,
                       f"Apertura de caja con ${monto_inicial:,.0f}")
        print(f"✓ Caja abierta con ${monto_inicial:,.0f}")

    def cierre_caja(self, usuario_id: str) -> dict:
        saldo = self._saldo_caja()
        self._mov_caja(usuario_id, "cierre", 0,
                       f"Cierre de caja. Saldo: ${saldo:,.0f}")
        ventas_hoy = self.db.q(
            """SELECT COUNT(*) as total_ventas, SUM(total) as ingresos
               FROM ventas WHERE date(fecha)=date('now') AND estado='completada'"""
        )
        return {
            "saldo_final": saldo,
            "total_ventas": ventas_hoy[0]["total_ventas"],
            "ingresos_hoy": ventas_hoy[0]["ingresos"] or 0
        }

    # ── REPORTES ──────────────────────────────────────

    def ventas_del_dia(self, fecha: str = None) -> dict:
        f = fecha or datetime.now().strftime("%Y-%m-%d")
        filas = self.db.q(
            """SELECT v.numero, v.total, v.metodo_pago, v.estado,
                      u.nombre as cajero, v.fecha
               FROM ventas v JOIN usuarios u ON u.id=v.usuario_id
               WHERE date(v.fecha)=?
               ORDER BY v.fecha DESC""", (f,)
        )
        total = sum(r["total"] for r in filas if r["estado"] == "completada")
        return {"fecha": f, "ventas": filas, "total_dia": total,
                "num_ventas": len(filas)}

    def productos_mas_vendidos(self, dias: int = 30, limite: int = 10) -> list:
        return self.db.q(
            """SELECT p.nombre, SUM(vi.cantidad) as unidades,
                      SUM(vi.subtotal) as ingresos
               FROM venta_items vi
               JOIN ventas v ON v.id=vi.venta_id
               JOIN productos p ON p.id=vi.producto_id
               WHERE v.fecha >= datetime('now', ?)
                 AND v.estado='completada'
               GROUP BY vi.producto_id
               ORDER BY unidades DESC LIMIT ?""",
            (f"-{dias} days", limite)
        )

    def resumen_inventario(self) -> dict:
        rows = self.db.q(
            """SELECT c.nombre as categoria,
                      COUNT(p.id) as productos,
                      SUM(p.stock_actual * p.precio_compra) as valor_inventario
               FROM productos p JOIN categorias c ON c.id=p.categoria_id
               WHERE p.activo=1
               GROUP BY c.id ORDER BY valor_inventario DESC"""
        )
        total_valor = sum(r["valor_inventario"] or 0 for r in rows)
        return {"categorias": rows, "valor_total": total_valor,
                "alertas_stock": len(self.stock_bajo())}

    def cerrar(self):
        self.db.cerrar()


# ─────────────────────────────────────────────────────
# DEMO
# ─────────────────────────────────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("  MINIMERCADO — Sistema de Base de Datos")
    print("=" * 55)

    mm = Minimercado()
    mm.iniciar()

    print("\n── Login ──")
    ses = mm.login("admin@minimercado.com", "Admin2024!")
    uid_admin = ses["usuario"]["id"]

    print("\n── Apertura de caja ──")
    mm.apertura_caja(uid_admin, 200_000)

    print("\n── Registrando venta de prueba ──")
    venta = mm.registrar_venta(
        usuario_id=uid_admin,
        items=[
            {"producto_id": "prd-001", "cantidad": 2},   # 2 leches
            {"producto_id": "prd-004", "cantidad": 1},   # 1 arroz
            {"producto_id": "prd-009", "cantidad": 3},   # 3 gaseosas
            {"producto_id": "prd-015", "cantidad": 2},   # 2 papas
        ],
        metodo_pago="efectivo"
    )
    print(f"  Venta registrada: {venta['numero']} — ${venta['total']:,.0f}")

    print("\n── Productos con stock bajo ──")
    alertas = mm.stock_bajo()
    if alertas:
        for p in alertas[:5]:
            print(f"  ⚠ {p['nombre']:30s} stock: {p['stock_actual']} / mín: {p['stock_minimo']}")
    else:
        print("  Sin alertas de stock")

    print("\n── Resumen de inventario ──")
    inv = mm.resumen_inventario()
    print(f"  Valor total inventario: ${inv['valor_total']:>12,.0f}")
    print(f"  Alertas de stock:       {inv['alertas_stock']}")
    for cat in inv["categorias"][:4]:
        print(f"  • {cat['categoria']:20s} {cat['productos']} prod.  "
              f"${cat['valor_inventario']:>10,.0f}")

    print("\n── Cierre de caja ──")
    cierre = mm.cierre_caja(uid_admin)
    print(f"  Saldo final:   ${cierre['saldo_final']:>10,.0f}")
    print(f"  Ventas del día: {cierre['total_ventas']}")
    print(f"  Ingresos:      ${cierre['ingresos_hoy']:>10,.0f}")

    mm.cerrar()
    print(f"\n✓ BD guardada en: {Config.DB_PATH}")
