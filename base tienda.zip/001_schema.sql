-- ============================================================
--  BASE DE DATOS - MINIMERCADO / TIENDA DE COMIDA
--  SQLite (local)  |  Compatible con PostgreSQL (Supabase)
-- ============================================================

PRAGMA foreign_keys = ON;
PRAGMA journal_mode  = WAL;

-- ────────────────────────────────────────
-- USUARIOS DEL SISTEMA
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usuarios (
    id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre       TEXT NOT NULL,
    email        TEXT NOT NULL UNIQUE,
    contrasena   TEXT NOT NULL,          -- hash bcrypt, NUNCA texto plano
    rol          TEXT NOT NULL DEFAULT 'cajero'
                     CHECK(rol IN ('admin','cajero','bodeguero')),
    activo       INTEGER NOT NULL DEFAULT 1,
    creado_en    TEXT NOT NULL DEFAULT (datetime('now')),
    ultimo_acceso TEXT
);

-- ────────────────────────────────────────
-- CATEGORÍAS DE PRODUCTOS
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categorias (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre      TEXT NOT NULL UNIQUE,
    descripcion TEXT,
    icono       TEXT DEFAULT 'shopping-bag',
    activa      INTEGER NOT NULL DEFAULT 1
);

-- ────────────────────────────────────────
-- PROVEEDORES
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS proveedores (
    id        TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre    TEXT NOT NULL,
    contacto  TEXT,
    telefono  TEXT,
    email     TEXT,
    direccion TEXT,
    activo    INTEGER NOT NULL DEFAULT 1,
    creado_en TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ────────────────────────────────────────
-- PRODUCTOS
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS productos (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    codigo_barras   TEXT UNIQUE,
    nombre          TEXT NOT NULL,
    descripcion     TEXT,
    categoria_id    TEXT NOT NULL,
    proveedor_id    TEXT,
    unidad_medida   TEXT NOT NULL DEFAULT 'unidad'
                        CHECK(unidad_medida IN ('unidad','kg','g','l','ml','docena','caja','paquete')),
    precio_compra   REAL NOT NULL DEFAULT 0,
    precio_venta    REAL NOT NULL DEFAULT 0,
    iva_porcentaje  REAL NOT NULL DEFAULT 0,      -- 0, 5 o 19 en Colombia
    stock_actual    REAL NOT NULL DEFAULT 0,
    stock_minimo    REAL NOT NULL DEFAULT 5,      -- alerta de reorden
    stock_maximo    REAL NOT NULL DEFAULT 100,
    imagen_url      TEXT,
    activo          INTEGER NOT NULL DEFAULT 1,
    creado_en       TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (categoria_id)  REFERENCES categorias(id),
    FOREIGN KEY (proveedor_id)  REFERENCES proveedores(id)
);

-- ────────────────────────────────────────
-- CLIENTES (opcional, para fidelización)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clientes (
    id             TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    nombre         TEXT NOT NULL,
    documento      TEXT UNIQUE,             -- cédula/NIT
    telefono       TEXT,
    email          TEXT,
    direccion      TEXT,
    saldo_puntos   REAL NOT NULL DEFAULT 0,
    creado_en      TEXT NOT NULL DEFAULT (datetime('now'))
);

-- ────────────────────────────────────────
-- VENTAS (cabecera)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ventas (
    id              TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    numero          TEXT NOT NULL UNIQUE,      -- VTA-2024-00001
    usuario_id      TEXT NOT NULL,
    cliente_id      TEXT,                      -- NULL = cliente anónimo
    subtotal        REAL NOT NULL DEFAULT 0,
    descuento       REAL NOT NULL DEFAULT 0,
    iva             REAL NOT NULL DEFAULT 0,
    total           REAL NOT NULL DEFAULT 0,
    metodo_pago     TEXT NOT NULL DEFAULT 'efectivo'
                        CHECK(metodo_pago IN ('efectivo','tarjeta','transferencia','nequi','daviplata','fiado')),
    estado          TEXT NOT NULL DEFAULT 'completada'
                        CHECK(estado IN ('completada','anulada','fiado')),
    notas           TEXT,
    fecha           TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- ────────────────────────────────────────
-- DETALLE DE VENTA
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS venta_items (
    id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    venta_id     TEXT NOT NULL,
    producto_id  TEXT NOT NULL,
    cantidad     REAL NOT NULL DEFAULT 1,
    precio_unit  REAL NOT NULL,
    descuento    REAL NOT NULL DEFAULT 0,
    iva_porc     REAL NOT NULL DEFAULT 0,
    subtotal     REAL NOT NULL,
    FOREIGN KEY (venta_id)    REFERENCES ventas(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- ────────────────────────────────────────
-- COMPRAS A PROVEEDORES (cabecera)
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS compras (
    id            TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    numero        TEXT NOT NULL UNIQUE,       -- CMP-2024-00001
    proveedor_id  TEXT NOT NULL,
    usuario_id    TEXT NOT NULL,
    total         REAL NOT NULL DEFAULT 0,
    estado        TEXT NOT NULL DEFAULT 'recibida'
                      CHECK(estado IN ('pendiente','recibida','parcial','cancelada')),
    factura_ref   TEXT,                        -- número de factura del proveedor
    notas         TEXT,
    fecha         TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
    FOREIGN KEY (usuario_id)   REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- DETALLE DE COMPRA
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS compra_items (
    id           TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    compra_id    TEXT NOT NULL,
    producto_id  TEXT NOT NULL,
    cantidad     REAL NOT NULL DEFAULT 1,
    precio_unit  REAL NOT NULL,
    subtotal     REAL NOT NULL,
    fecha_vence  TEXT,                    -- fecha de vencimiento del lote
    FOREIGN KEY (compra_id)   REFERENCES compras(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- ────────────────────────────────────────
-- CAJA / MOVIMIENTOS DE DINERO
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS movimientos_caja (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    usuario_id  TEXT NOT NULL,
    tipo        TEXT NOT NULL CHECK(tipo IN ('apertura','cierre','ingreso','egreso','venta','devolucion')),
    monto       REAL NOT NULL,
    saldo_antes REAL NOT NULL DEFAULT 0,
    saldo_des   REAL NOT NULL DEFAULT 0,
    concepto    TEXT NOT NULL,
    referencia  TEXT,                    -- id de venta o compra relacionada
    fecha       TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- DEVOLUCIONES
-- ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS devoluciones (
    id          TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    venta_id    TEXT NOT NULL,
    usuario_id  TEXT NOT NULL,
    motivo      TEXT NOT NULL,
    total       REAL NOT NULL DEFAULT 0,
    fecha       TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (venta_id)   REFERENCES ventas(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- ────────────────────────────────────────
-- ÍNDICES
-- ────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_productos_barcode  ON productos(codigo_barras);
CREATE INDEX IF NOT EXISTS idx_productos_cat      ON productos(categoria_id);
CREATE INDEX IF NOT EXISTS idx_productos_stock    ON productos(stock_actual);
CREATE INDEX IF NOT EXISTS idx_ventas_fecha       ON ventas(fecha);
CREATE INDEX IF NOT EXISTS idx_ventas_usuario     ON ventas(usuario_id);
CREATE INDEX IF NOT EXISTS idx_venta_items_venta  ON venta_items(venta_id);
CREATE INDEX IF NOT EXISTS idx_compras_prov       ON compras(proveedor_id);
CREATE INDEX IF NOT EXISTS idx_caja_fecha         ON movimientos_caja(fecha);
CREATE INDEX IF NOT EXISTS idx_usuarios_email     ON usuarios(email);

-- ════════════════════════════════════════
-- DATOS INICIALES
-- ════════════════════════════════════════

-- Categorías
INSERT OR IGNORE INTO categorias (id, nombre, descripcion, icono) VALUES
    ('cat-01', 'Lácteos y huevos',    'Leche, queso, yogur, mantequilla, huevos',  'egg'),
    ('cat-02', 'Carnes y embutidos',  'Res, cerdo, pollo, salchichas, jamón',       'meat'),
    ('cat-03', 'Frutas y verduras',   'Frutas frescas, verduras y hortalizas',      'apple'),
    ('cat-04', 'Panadería',           'Pan, ponqués, galletas artesanales',         'bread'),
    ('cat-05', 'Granos y harinas',    'Arroz, frijol, lenteja, harina, azúcar',    'wheat'),
    ('cat-06', 'Enlatados',           'Atún, sardinas, maíz, tomate en lata',      'package'),
    ('cat-07', 'Bebidas',             'Gaseosas, jugos, agua, cerveza',             'bottle'),
    ('cat-08', 'Aseo personal',       'Jabón, shampoo, crema dental, papel',       'droplet'),
    ('cat-09', 'Aseo del hogar',      'Detergente, desinfectante, esponjas',       'home'),
    ('cat-10', 'Snacks y dulces',     'Papas fritas, chocolates, chicles, café',   'coffee'),
    ('cat-11', 'Congelados',          'Helados, verduras congeladas, empanadas',   'snowflake'),
    ('cat-12', 'Bebé y niños',        'Pañales, fórmula, comida infantil',         'baby');

-- Proveedores
INSERT OR IGNORE INTO proveedores (id, nombre, contacto, telefono) VALUES
    ('prv-01', 'Distribuidora Lácteos del Valle', 'Carlos Gómez',    '310-111-2233'),
    ('prv-02', 'Carnes El Campesino',             'Martha Ríos',     '311-222-3344'),
    ('prv-03', 'Frutas y Verduras La Cosecha',    'Pedro Salcedo',   '312-333-4455'),
    ('prv-04', 'Distribuidora Nestlé',            'Ana Martínez',    '01800-912345'),
    ('prv-05', 'Almacenes Éxito Mayorista',       'Luis Herrera',    '313-444-5566');

-- Productos de ejemplo
INSERT OR IGNORE INTO productos
    (id, codigo_barras, nombre, categoria_id, proveedor_id, unidad_medida,
     precio_compra, precio_venta, iva_porcentaje, stock_actual, stock_minimo) VALUES
    ('prd-001','7702098010001','Leche entera 1L Alquería',    'cat-01','prv-01','unidad',  2800, 3500, 0,  50, 10),
    ('prd-002','7702098010002','Huevos AAA x12',              'cat-01','prv-01','docena',  4500, 5800, 0,  30,  8),
    ('prd-003','7702098010003','Queso campesino 500g',        'cat-01','prv-01','unidad',  7000, 9000, 0,  20,  5),
    ('prd-004','7702098010004','Arroz Diana 1kg',             'cat-05','prv-04','kg',      2200, 2800, 0, 100, 20),
    ('prd-005','7702098010005','Frijol bolo 500g',            'cat-05','prv-05','unidad',  2500, 3200, 0,  60, 10),
    ('prd-006','7702098010006','Aceite Gourmet 1L',           'cat-05','prv-04','unidad',  6800, 8500,19,  40,  8),
    ('prd-007','7702098010007','Azúcar refinada 1kg',         'cat-05','prv-04','kg',      2300, 2900, 0,  80, 15),
    ('prd-008','7702098010008','Atún Van Camps 170g',         'cat-06','prv-04','unidad',  2800, 3500,19,  70, 12),
    ('prd-009','7702098010009','Coca-Cola 400ml',             'cat-07','prv-04','unidad',  2000, 2800,19,  80, 20),
    ('prd-010','7702098010010','Agua Brisa 600ml',            'cat-07','prv-05','unidad',   900, 1500, 0, 120, 24),
    ('prd-011','7702098010011','Pan tajado Bimbo 480g',       'cat-04','prv-04','unidad',  4200, 5500, 0,  25,  6),
    ('prd-012','7702098010012','Jabón Rey x3',                'cat-08','prv-04','paquete', 5500, 7200, 0,  40, 10),
    ('prd-013','7702098010013','Papel higiénico x4',          'cat-08','prv-05','paquete', 5000, 6800, 0,  35,  8),
    ('prd-014','7702098010014','Detergente Ariel 500g',       'cat-09','prv-04','unidad',  7500, 9500, 0,  30,  6),
    ('prd-015','7702098010015','Papas Margarita 110g',        'cat-10','prv-04','unidad',  1800, 2500,19,  60, 15),
    ('prd-016','7702098010016','Café Colcafé 200g',           'cat-10','prv-04','unidad',  8500,11000, 0,  25,  6),
    ('prd-017','7702098010017','Salchichas Zenú x6',          'cat-02','prv-02','paquete', 5500, 7000, 0,  20,  5),
    ('prd-018','7702098010018','Yogur Alpina 200ml',          'cat-01','prv-01','unidad',  1800, 2500, 0,  30,  8),
    ('prd-019','7702098010019','Maíz dulce en lata 400g',     'cat-06','prv-05','unidad',  3200, 4200,19,  25,  6),
    ('prd-020','7702098010020','Crema dental Colgate 75ml',   'cat-08','prv-04','unidad',  3500, 4800, 0,  40, 10);

-- Usuario administrador
-- Contraseña: Admin2024!
INSERT OR IGNORE INTO usuarios (id, nombre, email, contrasena, rol) VALUES
    ('usr-admin-01','Administrador','admin@minimercado.com',
     '$2b$12$placeholder_reemplazar_al_iniciar','admin');

INSERT OR IGNORE INTO usuarios (id, nombre, email, contrasena, rol) VALUES
    ('usr-cajero-01','Cajero Principal','cajero@minimercado.com',
     '$2b$12$placeholder_reemplazar_al_iniciar','cajero');
