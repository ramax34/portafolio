# 🛒 Base de Datos — Minimercado / Tienda de Comida

Sistema completo de base de datos para minimercado. Funciona **sin internet** (SQLite local)
y se sincroniza con la nube (Supabase) cuando hay conexión.

---

## ⚡ Inicio rápido

```bash
pip install bcrypt PyJWT python-dotenv supabase requests
cp config/.env.ejemplo .env
python src/minimercado.py
```

---

## 🗄️ Tablas

| Tabla              | Descripción                                    |
|--------------------|------------------------------------------------|
| `usuarios`         | Empleados con rol y contraseña hasheada        |
| `categorias`       | Categorías de productos (12 incluidas)         |
| `proveedores`      | Proveedores y distribuidores                   |
| `productos`        | Catálogo con código de barras, stock, precios  |
| `clientes`         | Clientes registrados y puntos de fidelización  |
| `ventas`           | Ventas (cabecera): total, método de pago       |
| `venta_items`      | Detalle de cada venta (líneas de producto)     |
| `compras`          | Compras a proveedores                          |
| `compra_items`     | Detalle de cada compra con fecha de vencimiento|
| `movimientos_caja` | Registro de caja: aperturas, ventas, egresos   |
| `devoluciones`     | Devoluciones de productos                      |

---

## 👤 Roles

| Rol          | Permisos                                        |
|--------------|-------------------------------------------------|
| `admin`      | Todo: usuarios, precios, reportes, caja         |
| `cajero`     | Ventas, devoluciones, consulta de stock         |
| `bodeguero`  | Compras, actualización de stock, vencimientos   |

---

## 💻 Ejemplos de uso

```python
from src.minimercado import Minimercado

mm = Minimercado().iniciar()

# ── Login
sesion = mm.login("admin@minimercado.com", "Admin2024!")
uid = sesion["usuario"]["id"]

# ── Apertura de caja
mm.apertura_caja(uid, 200_000)

# ── Registrar una venta
venta = mm.registrar_venta(
    usuario_id=uid,
    items=[
        {"producto_id": "prd-001", "cantidad": 2},   # 2 leches
        {"producto_id": "prd-009", "cantidad": 3},   # 3 gaseosas
    ],
    metodo_pago="efectivo"   # efectivo | tarjeta | nequi | daviplata | fiado
)
print(f"Venta {venta['numero']}: ${venta['total']:,.0f}")

# ── Buscar producto (por nombre o código de barras)
resultados = mm.buscar_producto("leche")
resultados = mm.buscar_producto("7702001")  # por código de barras

# ── Crear producto nuevo
mm.crear_producto({
    "nombre":        "Panela cuadrada 500g",
    "categoria_id":  "cat-05",
    "precio_compra": 2200,
    "precio_venta":  2800,
    "stock_actual":  40,
    "stock_minimo":  10,
    "codigo_barras": "7703001001001",
    "iva_porcentaje": 0,
})

# ── Stock bajo (alertas)
alertas = mm.stock_bajo()

# ── Registrar compra a proveedor
mm.registrar_compra(
    proveedor_id="prv-01",
    usuario_id=uid,
    items=[
        {"producto_id": "prd-001", "cantidad": 48, "precio_unit": 2750,
         "fecha_vence": "2024-12-31"},
    ],
    factura_ref="FAC-001234"
)

# ── Reportes
print(mm.ventas_del_dia())
print(mm.productos_mas_vendidos(dias=30))
print(mm.resumen_inventario())

# ── Cierre de caja
cierre = mm.cierre_caja(uid)
print(f"Cierre: ${cierre['saldo_final']:,.0f} | Ventas: {cierre['total_ventas']}")
```

---

## 📦 Datos precargados

**12 categorías:** Lácteos, Carnes, Frutas/Verduras, Panadería, Granos, Enlatados, Bebidas, Aseo Personal, Aseo Hogar, Snacks, Congelados, Bebé y Niños.

**5 proveedores** de ejemplo listos para usar.

**20 productos** con precios, stock inicial y código de barras.

---

## 🔐 Seguridad

- Contraseñas: **bcrypt** (rounds=12). Nunca texto plano.
- Sesiones: **JWT** con expiración configurable.
- Stock: se descuenta automáticamente al vender y se suma al comprar.
- Anulación de ventas: restaura el stock automáticamente.

---

## 🔄 Modos de operación

| Situación           | Comportamiento                            |
|---------------------|-------------------------------------------|
| Sin internet        | Solo SQLite local, funciona normal        |
| Con internet + Supabase | Guarda en local Y en la nube          |
| Reconexión          | `mm.sincronizar()` sube datos pendientes  |

---

## 👤 Usuarios por defecto

| Email                      | Contraseña   | Rol    |
|----------------------------|--------------|--------|
| admin@minimercado.com      | Admin2024!   | admin  |
| cajero@minimercado.com     | Cajero2024!  | cajero |

> ⚠️ Cambia las contraseñas al poner en producción.

---

## 📁 Estructura

```
minimercado/
├── src/
│   └── minimercado.py          # Código principal
├── migrations/
│   └── 001_schema.sql          # Schema SQLite completo
├── config/
│   └── .env.ejemplo            # Plantilla de variables
└── README.md
```
